"""Input validation functions.

This module provides validation functionality for input data and parameters.
"""

import pandas as pd
from typing import List, Dict, Any, Union


class ValidationError(Exception):
    """Exception raised for validation errors."""
    pass


class InputValidator:
    """Validates input data and parameters."""
    
    @staticmethod
    def validate_dataframe(df: pd.DataFrame, required_columns: List[str]) -> bool:
        """Validate that a dataframe contains required columns."""
        missing = [col for col in required_columns if col not in df.columns]
        if missing:
            raise ValidationError(f"Missing required columns: {', '.join(missing)}")
        return True
        
    @staticmethod
    def validate_parameters(params: Dict[str, Any], required_params: Dict[str, type]) -> bool:
        """Validate that parameters have the required types."""
        for param_name, param_type in required_params.items():
            if param_name not in params:
                raise ValidationError(f"Missing required parameter: {param_name}")
                
            if not isinstance(params[param_name], param_type):
                raise ValidationError(
                    f"Parameter {param_name} has wrong type. Expected {param_type.__name__}, "
                    f"got {type(params[param_name]).__name__}"
                )
                
        return True

