"""Configuration management.

This module handles loading, validating, and providing access to configuration settings.
"""

import os
import json
from typing import Dict, Any, Optional

from .validators import ValidationError


class Config:
    """Manages configuration settings for the analysis pipeline."""
    
    def __init__(self, config_dict: Optional[Dict[str, Any]] = None, config_file: Optional[str] = None):
        self._config = {}
        
        if config_file and os.path.exists(config_file):
            self.load_from_file(config_file)
            
        if config_dict:
            self.update(config_dict)
            
    def load_from_file(self, config_file: str) -> None:
        """Load configuration from a JSON file."""
        try:
            with open(config_file, 'r') as f:
                config_data = json.load(f)
                self.update(config_data)
        except json.JSONDecodeError:
            raise ValidationError(f"Invalid JSON in config file: {config_file}")
            
    def update(self, config_dict: Dict[str, Any]) -> None:
        """Update configuration with values from a dictionary."""
        self._config.update(config_dict)
        
    def get(self, key: str, default: Any = None) -> Any:
        """Get a configuration value."""
        return self._config.get(key, default)
        
    def __getitem__(self, key: str) -> Any:
        """Get a configuration value using dictionary syntax."""
        return self._config[key]
        
    def __setitem__(self, key: str, value: Any) -> None:
        """Set a configuration value using dictionary syntax."""
        self._config[key] = value

