"""Progress reporting system.

This module provides functionality for tracking and reporting progress of long-running operations.
"""

import time
from enum import Enum
from typing import Callable, Optional, Dict, Any


class ProgressStage(Enum):
    """Enum representing different stages of the analysis pipeline."""
    LOADING = 'loading'
    PROCESSING = 'processing'
    ANALYSIS = 'analysis'
    VISUALIZATION = 'visualization'


class ProgressReporter:
    """Handles progress reporting and estimation for long-running tasks."""
    
    def __init__(self):
        self.start_time = None
        self.callback = None
        self.stages = {}
        
    def set_callback(self, callback: Callable[[str, float, Dict[str, Any]], None]):
        """Set the callback function for progress updates."""
        self.callback = callback
        
    def start_stage(self, stage_name: str, total_work: float = 1.0):
        """Start a new progress tracking stage."""
        self.stages[stage_name] = {
            'start_time': time.time(),
            'total_work': total_work,
            'completed_work': 0.0
        }
        if self.callback:
            self.callback(stage_name, 0.0, {'status': 'started'})
            
    def update_progress(self, stage_name: str, completed_work: float):
        """Update progress for a stage."""
        if stage_name not in self.stages:
            self.start_stage(stage_name)
            
        stage = self.stages[stage_name]
        stage['completed_work'] = completed_work
        
        if self.callback:
            progress = min(completed_work / stage['total_work'], 1.0)
            elapsed = time.time() - stage['start_time']
            
            # Estimate remaining time
            if progress > 0:
                estimated_total = elapsed / progress
                remaining = estimated_total - elapsed
            else:
                remaining = None
                
            self.callback(stage_name, progress, {
                'status': 'in_progress',
                'elapsed_seconds': elapsed,
                'estimated_remaining_seconds': remaining
            })
            
    def complete_stage(self, stage_name: str):
        """Mark a stage as complete."""
        if stage_name in self.stages:
            self.stages[stage_name]['completed_work'] = self.stages[stage_name]['total_work']
            
            if self.callback:
                elapsed = time.time() - self.stages[stage_name]['start_time']
                self.callback(stage_name, 1.0, {
                    'status': 'completed',
                    'elapsed_seconds': elapsed
                })

