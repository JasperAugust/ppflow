#!/usr/bin/env python3
"""
Run Analysis Script

This is a simple wrapper script that calls the analysis_runner module.
It's used by the Electron app as an entry point for running analyses.
"""

import sys
import os
import argparse
from ngs_analysis.pipeline.analysis_runner import (
    AnalysisRunner,
    console_progress_callback,
)


def main():
    """Main entry point."""
    # Create argument parser
    parser = argparse.ArgumentParser(
        description="Run NGS Analysis with the provided arguments"
    )

    # Add arguments - these should match the arguments expected by the analysis_runner module
    parser.add_argument(
        "--design", type=str, required=True, help="Path to design CSV file"
    )
    parser.add_argument("--output", type=str, required=True, help="Output directory")
    parser.add_argument("--control-peptide", type=str, help="Control peptide sequence")
    parser.add_argument(
        "--pseudocount",
        type=float,
        default=1.0,
        help="Pseudocount for fold change calculation",
    )
    parser.add_argument(
        "--fc-threshold",
        type=float,
        default=2.0,
        help="Fold change threshold for significance",
    )
    parser.add_argument(
        "--pval-threshold",
        type=float,
        default=0.05,
        help="P-value threshold for significance",
    )
    parser.add_argument(
        "--no-report", action="store_true", help="Disable report generation"
    )

    # Parse arguments
    args = parser.parse_args()

    # Convert arguments to config dictionary
    config = {
        "design_file": args.design,
        "output_dir": args.output,
        "control_peptide": args.control_peptide,
        "pseudocount": args.pseudocount,
        "fc_threshold": args.fc_threshold,
        "pval_threshold": args.pval_threshold,
        "generate_report": not args.no_report,
    }

    # Run analysis using the AnalysisRunner
    results = AnalysisRunner.run_from_args(config, console_progress_callback)

    # Return exit code based on analysis status
    if results and results.get("status") == "completed":
        return 0
    else:
        return 1


if __name__ == "__main__":
    sys.exit(main())
