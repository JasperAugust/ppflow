"""Pipeline orchestration.

This module handles the orchestration of the analysis workflow, managing the execution
of different analysis steps and maintaining state between operations.
"""

import os
import logging
from typing import Dict, Any, Optional, List, Tuple
import pandas as pd

from ..core.data_loader import DataLoader
from ..core.processor import DataProcessor
from ..core.statistics import StatisticalAnalyzer
from ..core.normalizer import Normalizer
from ..utils.progress import ProgressReporter


class AnalysisWorkflow:
    """Orchestrates the execution of the analysis pipeline."""

    def __init__(self, config=None):
        self.config = config or {}
        self.progress = ProgressReporter()
        self.cancel_flag = False

        # Set up default configuration values
        self.output_dir = self.config.get("output_dir", "results")
        os.makedirs(self.output_dir, exist_ok=True)

        # Store design file path
        self.design_file_path = None

        # Initialize components
        self.data_loader = DataLoader(config)
        self.processor = DataProcessor(config)
        self.statistics = StatisticalAnalyzer(config)
        self.normalizer = Normalizer(config)

        # Set up progress reporting
        self.data_loader.set_progress_callback(self._progress_callback)
        self.processor.set_progress_callback(self._progress_callback)
        self.statistics.set_progress_callback(self._progress_callback)
        self.normalizer.set_progress_callback(self._progress_callback)

        # Storage for intermediate results
        self.design_df = None
        self.input_data = {}
        self.merged_data = None
        self.results = None

    def set_progress_callback(self, callback):
        """Set callback function for progress updates."""
        self.progress.set_callback(callback)

    def _progress_callback(self, stage, progress, info):
        """Internal progress callback to forward component progress."""
        self.progress.update_progress(stage, progress)

    def request_cancellation(self):
        """Request cancellation of the current workflow."""
        self.cancel_flag = True
        self.data_loader.set_cancel_flag(True)
        self.processor.set_cancel_flag(True)
        self.statistics.set_cancel_flag(True)
        self.normalizer.set_cancel_flag(True)

    def run(self, design_file: str) -> dict:
        """Run the complete analysis workflow.

        Parameters:
        -----------
        design_file: str
            Path to design CSV file containing experiment metadata

        Returns:
        --------
        dict
            Results dictionary containing DataFrames and statistics
        """
        try:
            # Store design file path for potential reloading
            self.design_file_path = design_file

            # Initialize workflow
            self.progress.start_stage("workflow")
            logging.info(f"Starting analysis with design file: {design_file}")

            # Load and process data
            self._load_data(design_file)
            if self.cancel_flag:
                return self._create_results("cancelled")

            self._process_data()
            if self.cancel_flag:
                return self._create_results("cancelled")

            self._analyze_data()
            if self.cancel_flag:
                return self._create_results("cancelled")

            # Complete workflow
            self.progress.complete_stage("workflow")
            logging.info("Analysis completed successfully")

            return self._create_results("completed")

        except Exception as e:
            # Log and propagate exception
            logging.error(f"Error in workflow: {str(e)}", exc_info=True)
            return self._create_results("error", error=str(e))

    def _load_data(self, design_file: str) -> None:
        """Load input data from design file and sample files.

        Parameters:
        -----------
        design_file: str
            Path to design CSV file
        """
        self.progress.start_stage("loading_data")
        logging.info("Loading data for all samples...")

        # Load design file
        self.design_df = self.data_loader.read_design_file(design_file)

        # Read all peptide files referenced in the design file
        self.design_df = self.data_loader.read_all_peptide_files(self.design_df)

        # Split into different roles: inputs, references, and experimental samples
        input_mask = self.design_df["role"] == "Input"
        reference_mask = self.design_df["role"] == "Reference"
        sample_mask = self.design_df["role"] == "Sample"

        input_df = self.design_df[input_mask]
        reference_df = (
            self.design_df[reference_mask]
            if "Reference" in self.design_df["role"].values
            else pd.DataFrame()
        )
        self.sample_df = self.design_df[sample_mask]

        # Verify we have at least some samples
        if self.sample_df.empty:
            raise ValueError(
                "No samples found in design file (rows with role='Sample')"
            )

        # Store reference data if available
        self.reference_data = {}
        if not reference_df.empty:
            logging.info("Preparing reference data")
            self.reference_data = self.data_loader.prepare_input_references(
                reference_df
            )

        # Prepare input references for each condition
        logging.info("Preparing input references per condition")
        self.input_data = self.data_loader.prepare_input_references(input_df)

        # Validate that we have input data for all conditions
        sample_conditions = set(self.sample_df["condition"].unique())
        input_conditions = set(self.input_data.keys())

        # Identify conditions without input samples
        missing_conditions = sample_conditions - input_conditions
        if missing_conditions and not self.reference_data:
            logging.warning(f"Missing input data for conditions: {missing_conditions}")
            raise ValueError(
                f"No input data for conditions: {', '.join(missing_conditions)}"
            )
        elif missing_conditions:
            # If we have reference data, we can use it for the missing conditions
            logging.info(
                f"Using reference data for conditions without inputs: {missing_conditions}"
            )
            for condition in missing_conditions:
                self.input_data[condition] = list(self.reference_data.values())[0]

        self.progress.complete_stage("loading_data")

    def _process_data(self) -> None:
        """Process the loaded data."""
        self.progress.start_stage("processing_data")
        logging.info("Processing data...")

        # Merge all sample data into one DataFrame
        logging.info("Merging sample data...")
        self.merged_data = self.processor.merge_all_data(self.sample_df)

        # Calculate fold change vs input references
        logging.info("Calculating fold changes...")
        self.merged_data = self.processor.calculate_fold_change(
            self.merged_data,
            self.input_data,
            cpm_column="CPM_per_mg",
            input_cpm_column="CPM",
        )

        # Calculate fold over control
        logging.info("Calculating fold over control...")
        control_peptide = self.config.get("control_peptide", "CGGGGGGGC")
        self.merged_data = self.normalizer.compute_fold_over_control(
            self.merged_data, control_peptide=control_peptide, cpm_col="CPM_per_mg"
        )

        self.progress.complete_stage("processing_data")

    def _analyze_data(self) -> None:
        """Analyze the processed data."""
        self.progress.start_stage("analysis")
        logging.info("Performing statistical analysis...")

        # Perform statistical testing across replicates
        self.stats_df = self.statistics.perform_stats(
            self.merged_data, fc_column="log2FC_vs_input"
        )

        # Find enriched and depleted peptides
        fc_threshold = self.config.get("fc_threshold", 1.0)  # log2FC threshold (2-fold)
        pval_threshold = self.config.get("pval_threshold", 0.05)
        min_replicates = self.config.get("min_replicates", 2)

        # Find enriched peptides (positive fold change, significant)
        self.enriched_df = self.statistics.find_enriched_peptides(
            self.stats_df,
            fc_threshold=fc_threshold,
            adjusted_p_threshold=pval_threshold,
            min_replicates=min_replicates,
        )

        # Find depleted peptides (negative fold change, significant)
        self.depleted_df = self.statistics.find_depleted_peptides(
            self.stats_df,
            fc_threshold=-fc_threshold,  # Negative threshold for depletion
            adjusted_p_threshold=pval_threshold,
            min_replicates=min_replicates,
        )

        # Compare conditions if multiple conditions present
        conditions = self.merged_data["condition"].unique()
        self.condition_comparisons = {}

        if len(conditions) > 1:
            # Perform pairwise comparisons
            for i, cond1 in enumerate(conditions):
                for cond2 in conditions[i + 1 :]:
                    logging.info(f"Comparing conditions: {cond1} vs {cond2}")

                    comparison_df = self.statistics.compare_conditions(
                        self.merged_data,
                        condition1=cond1,
                        condition2=cond2,
                        fc_column="log2FC_vs_input",
                    )

                    # Store comparison results
                    comparison_key = f"{cond1}_vs_{cond2}"
                    self.condition_comparisons[comparison_key] = comparison_df

        # Store combined results in results_df
        self.results_df = self.merged_data

        self.progress.complete_stage("analysis")

    def _create_results(self, status: str, error: str = None) -> dict:
        """Create a results dictionary with all relevant data.

        Parameters:
        -----------
        status: str
            Status of the analysis (completed, cancelled, error)
        error: str
            Error message if status is 'error'

        Returns:
        --------
        dict
            Results dictionary with analysis data
        """
        results = {
            "status": status,
            "design_df": self.design_df,
            "input_data": self.input_data,
            "merged_data": self.merged_data,
            "results_df": getattr(self, "results_df", None),
            "stats_df": getattr(self, "stats_df", None),
            "enriched_df": getattr(self, "enriched_df", None),
            "depleted_df": getattr(self, "depleted_df", None),
            "condition_comparisons": getattr(self, "condition_comparisons", {}),
            "output_dir": self.output_dir,
        }

        if error:
            results["error"] = error

        return results

    def reload_design_file(self) -> dict:
        """Reload the experiment design file and update analysis.

        This allows for modifications to the design file to be applied
        after the initial preprocessing has been done.

        Returns:
        --------
        dict
            Updated results dictionary
        """
        if not self.design_file_path:
            error_msg = "No design file has been loaded. Run analysis first."
            logging.error(error_msg)
            return self._create_results("error", error=error_msg)

        try:
            logging.info(f"Reloading design file: {self.design_file_path}")

            # Clear existing input data
            self.input_data = {}

            # Reload data from design file
            self._load_data(self.design_file_path)
            if self.cancel_flag:
                return self._create_results("cancelled")

            # Reprocess and reanalyze data
            self._process_data()
            if self.cancel_flag:
                return self._create_results("cancelled")

            self._analyze_data()
            if self.cancel_flag:
                return self._create_results("cancelled")

            logging.info("Design file reloaded and analysis updated successfully")
            return self._create_results("completed")

        except Exception as e:
            logging.error(f"Error reloading design file: {str(e)}", exc_info=True)
            return self._create_results("error", error=str(e))
