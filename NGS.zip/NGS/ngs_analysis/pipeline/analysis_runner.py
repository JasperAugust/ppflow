"""Main entry point for the analysis pipeline.

This module provides the main entry point for running the analysis pipeline,
with functions for both programmatic and command-line usage.
"""

import os
import sys
import argparse
import json
import logging
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union, Any, Callable

from ..utils.config import Config
from .workflow import AnalysisWorkflow
from ..visualization.reporter import Reporter


class AnalysisRunner:
    """Main entry point for running the analysis pipeline."""

    @staticmethod
    def run_from_config(config_file: str, progress_callback: Optional[Callable] = None):
        """Run analysis using a configuration file.

        Parameters:
        -----------
        config_file: str
            Path to configuration file (JSON)
        progress_callback: callable
            Function to call with progress updates

        Returns:
        --------
        dict
            Results from the analysis
        """
        # Set up logging
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        # Load configuration
        try:
            config = Config(config_file=config_file)
        except Exception as e:
            logging.error(f"Error loading configuration: {str(e)}")
            return {"status": "error", "error": f"Configuration error: {str(e)}"}

        # Create and run workflow
        workflow = AnalysisWorkflow(config)

        if progress_callback:
            workflow.set_progress_callback(progress_callback)

        # Get design file from config
        design_file = config.get("design_file")
        if not design_file:
            logging.error("No design file specified in configuration")
            return {"status": "error", "error": "No design file specified"}

        # Run the workflow
        try:
            results = workflow.run(design_file)

            # Generate reports if analysis completed successfully
            if results["status"] == "completed" and config.get("generate_report", True):
                reporter = Reporter(config)
                report_files = reporter.generate_full_report(results)
                results["report_files"] = report_files

            return results
        except Exception as e:
            logging.error(f"Error running workflow: {str(e)}", exc_info=True)
            return {"status": "error", "error": f"Workflow error: {str(e)}"}

    @staticmethod
    def run_from_args(
        args: Dict[str, Any], progress_callback: Optional[Callable] = None
    ):
        """Run analysis using a dictionary of arguments.

        Parameters:
        -----------
        args: dict
            Dictionary of arguments
        progress_callback: callable
            Function to call with progress updates

        Returns:
        --------
        dict
            Results from the analysis
        """
        # Set up logging
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        # Create configuration from arguments
        config = Config(config_dict=args)

        # Create workflow
        workflow = AnalysisWorkflow(config)

        if progress_callback:
            workflow.set_progress_callback(progress_callback)

        # Get design file from args
        design_file = args.get("design_file")
        if not design_file:
            logging.error("No design file specified in arguments")
            return {"status": "error", "error": "No design file specified"}

        # Run the workflow
        try:
            results = workflow.run(design_file)

            # Generate reports if analysis completed successfully
            if results["status"] == "completed" and args.get("generate_report", True):
                reporter = Reporter(config)
                report_files = reporter.generate_full_report(results)
                results["report_files"] = report_files

            return results
        except Exception as e:
            logging.error(f"Error running workflow: {str(e)}", exc_info=True)
            return {"status": "error", "error": f"Workflow error: {str(e)}"}

    @staticmethod
    def reload_design_file(workflow: AnalysisWorkflow) -> dict:
        """Reload the experiment design file and update analysis.

        This allows for modifications to the design file to be applied
        after the initial preprocessing has been done.

        Parameters:
        -----------
        workflow: AnalysisWorkflow
            An existing workflow instance with a previously loaded design file

        Returns:
        --------
        dict
            Updated results dictionary
        """
        try:
            # Reload the design file and update analysis
            results = workflow.reload_design_file()

            # Generate reports if analysis completed successfully
            if results["status"] == "completed" and workflow.config.get(
                "generate_report", True
            ):
                reporter = Reporter(workflow.config)
                report_files = reporter.generate_full_report(results)
                results["report_files"] = report_files

            return results
        except Exception as e:
            logging.error(f"Error reloading design file: {str(e)}", exc_info=True)
            return {"status": "error", "error": f"Reload error: {str(e)}"}


def console_progress_callback(stage, progress, info=None):
    """Simple progress callback that prints to console."""
    bar_length = 30
    filled_length = int(bar_length * progress)
    bar = "█" * filled_length + "░" * (bar_length - filled_length)

    # Format progress as percentage
    percent = min(progress * 100, 100)

    # Print progress bar
    sys.stdout.write(f"\r{stage}: [{bar}] {percent:.1f}%")
    sys.stdout.flush()

    # Print newline if complete
    if progress >= 1.0:
        sys.stdout.write("\n")


def main():
    """Command-line entry point."""
    parser = argparse.ArgumentParser(description="NGS Analysis Pipeline")

    parser.add_argument("--config", type=str, help="Path to configuration file (JSON)")
    parser.add_argument("--design", type=str, help="Path to experiment design CSV file")
    parser.add_argument("--output", type=str, help="Output directory")
    parser.add_argument(
        "--pseudocount",
        type=float,
        default=1.0,
        help="Pseudocount for fold change calculation",
    )
    parser.add_argument(
        "--cpm-scale",
        type=float,
        default=1e6,
        help="Scale factor for counts per million",
    )
    parser.add_argument("--log-file", type=str, help="Log file path")
    parser.add_argument(
        "--no-report", action="store_true", help="Disable report generation"
    )
    parser.add_argument(
        "--control-peptide",
        type=str,
        default="CGGGGGGGC",
        help="Control peptide sequence",
    )
    parser.add_argument(
        "--fc-threshold",
        type=float,
        default=1.0,
        help="Log2 fold change threshold for significance",
    )
    parser.add_argument(
        "--pval-threshold",
        type=float,
        default=0.05,
        help="P-value threshold for significance",
    )

    args = parser.parse_args()

    # Set up logging
    log_level = logging.INFO
    log_format = "%(asctime)s - %(levelname)s - %(message)s"
    log_datefmt = "%Y-%m-%d %H:%M:%S"

    if args.log_file:
        logging.basicConfig(
            level=log_level,
            format=log_format,
            datefmt=log_datefmt,
            filename=args.log_file,
            filemode="w",
        )
        # Also log to console
        console = logging.StreamHandler()
        console.setLevel(log_level)
        console.setFormatter(logging.Formatter(log_format, datefmt=log_datefmt))
        logging.getLogger("").addHandler(console)
    else:
        logging.basicConfig(level=log_level, format=log_format, datefmt=log_datefmt)

    # Log startup information
    logging.info("NGS Analysis Pipeline starting")

    if args.config:
        # Run from config file
        logging.info(f"Running with configuration file: {args.config}")
        results = AnalysisRunner.run_from_config(args.config, console_progress_callback)
    elif args.design:
        # Run from command line arguments
        logging.info(f"Running with design file: {args.design}")
        run_args = {
            "design_file": args.design,
            "output_dir": args.output or "results",
            "pseudocount": args.pseudocount,
            "cpm_scale": args.cpm_scale,
            "generate_report": not args.no_report,
            "control_peptide": args.control_peptide,
            "fc_threshold": args.fc_threshold,
            "pval_threshold": args.pval_threshold,
        }
        results = AnalysisRunner.run_from_args(run_args, console_progress_callback)
    else:
        parser.print_help()
        sys.exit(1)

    # Check status
    if results["status"] == "completed":
        output_dir = results.get("output_dir", "results")
        logging.info(f"Analysis completed successfully. Results saved to {output_dir}")

        # Print report files
        if results.get("report_files"):
            logging.info("Generated report files:")
            for section, files in results["report_files"].items():
                if files:
                    logging.info(f"  {section.capitalize()} files:")
                    for f in files:
                        logging.info(f"    - {f}")

        sys.exit(0)
    else:
        # Error occurred
        error_msg = results.get("error", "Unknown error")
        logging.error(f"Analysis failed: {error_msg}")
        sys.exit(1)


if __name__ == "__main__":
    main()
