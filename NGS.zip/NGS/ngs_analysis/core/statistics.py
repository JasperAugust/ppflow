"""Statistical analysis module.

This module provides statistical methods for analyzing phage display data,
including calculating significance, p-values, and multiple testing corrections.
"""

import numpy as np
import pandas as pd
import scipy.stats as stats
import logging
from typing import Dict, List, Optional, Tuple, Union
from statsmodels.stats.multitest import multipletests


class StatisticalAnalyzer:
    """Performs statistical analysis on phage display data."""

    def __init__(self, config=None):
        self.config = config or {}
        self._progress_callback = None
        self._cancel_flag = False

        # Default configuration
        self.alpha = self.config.get("alpha", 0.05)  # Significance level
        self.correction_method = self.config.get(
            "correction_method", "fdr_bh"
        )  # Multiple testing correction method
        self.min_replicates = self.config.get(
            "min_replicates", 2
        )  # Minimum number of replicates required

    def set_progress_callback(self, callback):
        """Set callback function for progress updates."""
        self._progress_callback = callback

    def set_cancel_flag(self, flag):
        """Set flag to request cancellation of operations."""
        self._cancel_flag = flag

    def perform_stats(
        self, merged_df: pd.DataFrame, fc_column: str = "log2FC_vs_input"
    ) -> pd.DataFrame:
        """Perform statistical analysis on the dataset.

        Parameters:
        -----------
        merged_df: pd.DataFrame
            Merged DataFrame containing all samples with fold change values
        fc_column: str
            Column name containing fold change values

        Returns:
        --------
        pd.DataFrame
            DataFrame with statistical results
        """
        if merged_df.empty:
            return pd.DataFrame()

        # Check if required columns exist
        required_columns = {fc_column, "Peptide", "condition", "mouse_id"}
        if not required_columns.issubset(merged_df.columns):
            missing = required_columns - set(merged_df.columns)
            raise ValueError(f"DataFrame missing required columns: {missing}")

        # Calculate summary statistics per condition and peptide
        stats_df = self._calculate_summary_statistics(merged_df, fc_column)

        # Perform multiple testing correction
        stats_df = self._apply_multiple_testing_correction(stats_df)

        return stats_df

    def _calculate_summary_statistics(
        self, merged_df: pd.DataFrame, fc_column: str
    ) -> pd.DataFrame:
        """Calculate summary statistics for each peptide across replicates.

        Parameters:
        -----------
        merged_df: pd.DataFrame
            Merged DataFrame containing all samples
        fc_column: str
            Column name containing fold change values

        Returns:
        --------
        pd.DataFrame
            DataFrame with summary statistics
        """
        # Initialize progress
        if self._progress_callback:
            self._progress_callback("calc_stats", 0.0, {})

        # Create a list to store results
        results = []

        # Get unique conditions and peptides
        conditions = merged_df["condition"].unique()
        peptides = merged_df["Peptide"].unique()

        total_combinations = len(conditions) * len(peptides)
        processed = 0

        # Process each condition and peptide
        for condition in conditions:
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Statistical analysis cancelled by user")
                break

            cond_df = merged_df[merged_df["condition"] == condition]

            for peptide in peptides:
                # Get data for this peptide in this condition
                peptide_df = cond_df[cond_df["Peptide"] == peptide]

                # Skip if not enough replicates
                if len(peptide_df) < self.min_replicates:
                    continue

                # Calculate statistics
                fc_values = peptide_df[fc_column].dropna().values

                # Skip if no valid values
                if len(fc_values) < self.min_replicates:
                    continue

                # Basic statistics
                mean_fc = np.mean(fc_values)
                median_fc = np.median(fc_values)
                std_fc = np.std(fc_values, ddof=1)  # Sample standard deviation
                sem_fc = std_fc / np.sqrt(len(fc_values))  # Standard error of the mean

                # Calculate 95% confidence interval
                # For small n, use t-distribution
                if len(fc_values) < 30:
                    t_critical = stats.t.ppf(0.975, len(fc_values) - 1)
                    ci_95_low = mean_fc - t_critical * sem_fc
                    ci_95_high = mean_fc + t_critical * sem_fc
                else:
                    # For large n, can use normal approximation
                    z_critical = stats.norm.ppf(0.975)
                    ci_95_low = mean_fc - z_critical * sem_fc
                    ci_95_high = mean_fc + z_critical * sem_fc

                # One-sample t-test against 0 (no change)
                try:
                    t_stat, p_value = stats.ttest_1samp(fc_values, 0)
                except:
                    t_stat, p_value = np.nan, np.nan

                # Store results
                result = {
                    "Peptide": peptide,
                    "condition": condition,
                    "mean_log2FC": mean_fc,
                    "median_log2FC": median_fc,
                    "std_log2FC": std_fc,
                    "sem_log2FC": sem_fc,
                    "ci_95_low": ci_95_low,
                    "ci_95_high": ci_95_high,
                    "t_stat": t_stat,
                    "p_value": p_value,
                    "n_replicates": len(fc_values),
                }
                results.append(result)

                # Update progress
                processed += 1
                if self._progress_callback:
                    progress = min(processed / total_combinations, 1.0)
                    self._progress_callback(
                        "calc_stats",
                        progress,
                        {"processed": processed, "total": total_combinations},
                    )

        # Create DataFrame from results
        if not results:
            return pd.DataFrame()

        stats_df = pd.DataFrame(results)

        # Complete progress
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback("calc_stats", 1.0, {})

        return stats_df

    def _apply_multiple_testing_correction(
        self, stats_df: pd.DataFrame
    ) -> pd.DataFrame:
        """Apply multiple testing correction to p-values.

        Parameters:
        -----------
        stats_df: pd.DataFrame
            DataFrame with statistical results including p-values

        Returns:
        --------
        pd.DataFrame
            DataFrame with adjusted p-values
        """
        if stats_df.empty or "p_value" not in stats_df.columns:
            return stats_df

        # Initialize progress
        if self._progress_callback:
            self._progress_callback("multiple_testing", 0.0, {})

        # Apply correction separately for each condition
        result_dfs = []

        conditions = stats_df["condition"].unique()
        for i, condition in enumerate(conditions):
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Multiple testing correction cancelled by user")
                break

            # Get data for this condition
            cond_df = stats_df[stats_df["condition"] == condition].copy()

            # Skip if empty
            if cond_df.empty:
                continue

            # Apply multiple testing correction
            p_values = cond_df["p_value"].values

            # Handle NaN values
            mask = ~np.isnan(p_values)
            if sum(mask) > 0:
                try:
                    rejected, adjusted_p, _, _ = multipletests(
                        p_values[mask], alpha=self.alpha, method=self.correction_method
                    )

                    # Initialize adjusted p-values with NaN
                    adjusted_p_full = np.full_like(p_values, np.nan)

                    # Replace values where mask is True
                    adjusted_p_full[mask] = adjusted_p

                    # Add to DataFrame
                    cond_df["adjusted_p"] = adjusted_p_full
                    cond_df["significant"] = False
                    cond_df.loc[mask, "significant"] = rejected
                except Exception as e:
                    logging.warning(
                        f"Error applying multiple testing correction: {str(e)}"
                    )
                    cond_df["adjusted_p"] = np.nan
                    cond_df["significant"] = False
            else:
                cond_df["adjusted_p"] = np.nan
                cond_df["significant"] = False

            result_dfs.append(cond_df)

            # Update progress
            if self._progress_callback:
                progress = (i + 1) / len(conditions)
                self._progress_callback(
                    "multiple_testing",
                    progress,
                    {
                        "condition": condition,
                        "processed": i + 1,
                        "total": len(conditions),
                    },
                )

        # Combine results
        if not result_dfs:
            return stats_df

        result_df = pd.concat(result_dfs, ignore_index=True)

        # Complete progress
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback("multiple_testing", 1.0, {})

        return result_df

    def compare_conditions(
        self,
        merged_df: pd.DataFrame,
        condition1: str,
        condition2: str,
        fc_column: str = "log2FC_vs_input",
    ) -> pd.DataFrame:
        """Compare two conditions to identify differentially enriched peptides.

        Parameters:
        -----------
        merged_df: pd.DataFrame
            Merged DataFrame containing all samples
        condition1: str
            First condition to compare
        condition2: str
            Second condition to compare
        fc_column: str
            Column name containing fold change values

        Returns:
        --------
        pd.DataFrame
            DataFrame with differential statistics
        """
        if merged_df.empty:
            return pd.DataFrame()

        # Check if required columns exist
        required_columns = {fc_column, "Peptide", "condition", "mouse_id"}
        if not required_columns.issubset(merged_df.columns):
            missing = required_columns - set(merged_df.columns)
            raise ValueError(f"DataFrame missing required columns: {missing}")

        # Check if conditions exist
        if condition1 not in merged_df["condition"].unique():
            raise ValueError(f"Condition {condition1} not found in data")
        if condition2 not in merged_df["condition"].unique():
            raise ValueError(f"Condition {condition2} not found in data")

        # Initialize progress
        if self._progress_callback:
            self._progress_callback(
                "compare_conditions",
                0.0,
                {"condition1": condition1, "condition2": condition2},
            )

        # Get data for each condition
        cond1_df = merged_df[merged_df["condition"] == condition1]
        cond2_df = merged_df[merged_df["condition"] == condition2]

        # Get peptides in both conditions
        peptides = set(cond1_df["Peptide"].unique()) & set(cond2_df["Peptide"].unique())

        results = []
        for i, peptide in enumerate(peptides):
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Condition comparison cancelled by user")
                break

            # Get data for this peptide
            peptide_cond1 = cond1_df[cond1_df["Peptide"] == peptide]
            peptide_cond2 = cond2_df[cond2_df["Peptide"] == peptide]

            # Skip if not enough replicates
            if (
                len(peptide_cond1) < self.min_replicates
                or len(peptide_cond2) < self.min_replicates
            ):
                continue

            # Get fold change values
            fc1 = peptide_cond1[fc_column].dropna().values
            fc2 = peptide_cond2[fc_column].dropna().values

            # Skip if not enough valid values
            if len(fc1) < self.min_replicates or len(fc2) < self.min_replicates:
                continue

            # Calculate difference in means
            mean_diff = np.mean(fc1) - np.mean(fc2)

            # Perform t-test (two-sample, unpaired)
            try:
                # Equal variance t-test
                t_stat, p_value = stats.ttest_ind(fc1, fc2, equal_var=False)
            except:
                t_stat, p_value = np.nan, np.nan

            # Calculate fold change ratio (non-log scale)
            # log2FC1 - log2FC2 = log2(FC1/FC2)
            # So fold ratio = 2^(mean_diff)
            fold_ratio = 2**mean_diff

            # Store result
            result = {
                "Peptide": peptide,
                "condition1": condition1,
                "condition2": condition2,
                "mean_log2FC_cond1": np.mean(fc1),
                "mean_log2FC_cond2": np.mean(fc2),
                "log2FC_diff": mean_diff,  # Difference in log2 scale
                "fold_ratio": fold_ratio,  # Ratio in linear scale
                "t_stat": t_stat,
                "p_value": p_value,
                "n_replicates_cond1": len(fc1),
                "n_replicates_cond2": len(fc2),
            }
            results.append(result)

            # Update progress
            if self._progress_callback:
                progress = (i + 1) / len(peptides)
                self._progress_callback(
                    "compare_conditions",
                    progress,
                    {"processed": i + 1, "total": len(peptides)},
                )

        # Create DataFrame
        if not results:
            return pd.DataFrame()

        result_df = pd.DataFrame(results)

        # Apply multiple testing correction
        if not result_df.empty and "p_value" in result_df.columns:
            p_values = result_df["p_value"].values

            # Handle NaN values
            mask = ~np.isnan(p_values)
            if sum(mask) > 0:
                try:
                    rejected, adjusted_p, _, _ = multipletests(
                        p_values[mask], alpha=self.alpha, method=self.correction_method
                    )

                    # Initialize adjusted p-values with NaN
                    adjusted_p_full = np.full_like(p_values, np.nan)

                    # Replace values where mask is True
                    adjusted_p_full[mask] = adjusted_p

                    # Add to DataFrame
                    result_df["adjusted_p"] = adjusted_p_full
                    result_df["significant"] = False
                    result_df.loc[mask, "significant"] = rejected
                except Exception as e:
                    logging.warning(
                        f"Error applying multiple testing correction: {str(e)}"
                    )
                    result_df["adjusted_p"] = np.nan
                    result_df["significant"] = False
            else:
                result_df["adjusted_p"] = np.nan
                result_df["significant"] = False

        # Complete progress
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback("compare_conditions", 1.0, {})

        return result_df

    def find_enriched_peptides(
        self,
        stats_df: pd.DataFrame,
        fc_threshold: float = 1.0,  # log2FC threshold (2-fold)
        adjusted_p_threshold: float = 0.05,
        min_replicates: int = 2,
    ) -> pd.DataFrame:
        """Find significantly enriched peptides based on thresholds.

        Parameters:
        -----------
        stats_df: pd.DataFrame
            DataFrame with statistical results from perform_stats method
        fc_threshold: float
            Log2 fold change threshold (default: 1.0, meaning 2-fold)
        adjusted_p_threshold: float
            Adjusted p-value threshold (default: 0.05)
        min_replicates: int
            Minimum number of replicates required (default: 2)

        Returns:
        --------
        pd.DataFrame
            DataFrame with filtered results containing only enriched peptides
        """
        if stats_df.empty:
            return pd.DataFrame()

        # Check required columns
        required_columns = {
            "Peptide",
            "condition",
            "mean_log2FC",
            "adjusted_p",
            "n_replicates",
        }
        if not required_columns.issubset(stats_df.columns):
            missing = required_columns - set(stats_df.columns)
            raise ValueError(f"Stats DataFrame missing required columns: {missing}")

        # Filter for enriched peptides
        enriched = stats_df[
            (stats_df["mean_log2FC"] >= fc_threshold)  # Higher than threshold
            & (stats_df["adjusted_p"] <= adjusted_p_threshold)  # Significant
            & (stats_df["n_replicates"] >= min_replicates)  # Sufficient replicates
        ].copy()

        # Sort by fold change (highest first)
        enriched = enriched.sort_values(
            ["condition", "mean_log2FC"], ascending=[True, False]
        )

        return enriched

    def find_depleted_peptides(
        self,
        stats_df: pd.DataFrame,
        fc_threshold: float = -1.0,  # log2FC threshold (0.5-fold)
        adjusted_p_threshold: float = 0.05,
        min_replicates: int = 2,
    ) -> pd.DataFrame:
        """Find significantly depleted peptides based on thresholds.

        Parameters:
        -----------
        stats_df: pd.DataFrame
            DataFrame with statistical results from perform_stats method
        fc_threshold: float
            Log2 fold change threshold (default: -1.0, meaning 0.5-fold)
        adjusted_p_threshold: float
            Adjusted p-value threshold (default: 0.05)
        min_replicates: int
            Minimum number of replicates required (default: 2)

        Returns:
        --------
        pd.DataFrame
            DataFrame with filtered results containing only depleted peptides
        """
        if stats_df.empty:
            return pd.DataFrame()

        # Check required columns
        required_columns = {
            "Peptide",
            "condition",
            "mean_log2FC",
            "adjusted_p",
            "n_replicates",
        }
        if not required_columns.issubset(stats_df.columns):
            missing = required_columns - set(stats_df.columns)
            raise ValueError(f"Stats DataFrame missing required columns: {missing}")

        # Filter for depleted peptides
        depleted = stats_df[
            (stats_df["mean_log2FC"] <= fc_threshold)  # Lower than threshold
            & (stats_df["adjusted_p"] <= adjusted_p_threshold)  # Significant
            & (stats_df["n_replicates"] >= min_replicates)  # Sufficient replicates
        ].copy()

        # Sort by fold change (lowest first)
        depleted = depleted.sort_values(
            ["condition", "mean_log2FC"], ascending=[True, True]
        )

        return depleted
