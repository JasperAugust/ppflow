"""Data processing and transformation module.

This module handles data transformation, preparation, and manages
memory-efficient operations on large datasets.
"""

import numpy as np
import pandas as pd
import logging
from typing import Dict, List, Optional, Union


class DataProcessor:
    """Handles data transformation and preparation for analysis."""

    def __init__(self, config=None):
        self.config = config or {}
        self._progress_callback = None
        self._cancel_flag = False

        # Default configuration
        self.pseudocount = self.config.get("pseudocount", 1.0)
        self.cpm_scale = self.config.get("cpm_scale", 1e6)

    def set_progress_callback(self, callback):
        """Set callback function for progress updates."""
        self._progress_callback = callback

    def set_cancel_flag(self, flag):
        """Set flag to request cancellation of operations."""
        self._cancel_flag = flag

    def merge_all_data(self, sample_df: pd.DataFrame) -> pd.DataFrame:
        """Combine all sample data into one consolidated DataFrame.

        Parameters:
        -----------
        sample_df: pd.DataFrame
            DataFrame containing sample data with a 'data' column of peptide DataFrames

        Returns:
        --------
        pd.DataFrame
            Combined DataFrame with all samples and metadata
        """
        if "data" not in sample_df.columns:
            raise ValueError("Sample DataFrame must have a 'data' column")

        # Initialize progress reporting
        total_samples = len(sample_df)
        if self._progress_callback:
            self._progress_callback(
                "merging_data", 0.0, {"total_samples": total_samples}
            )

        all_rows = []
        for idx, row in sample_df.iterrows():
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Merging data cancelled by user")
                break

            # Get peptide data for this sample
            df = row["data"]
            if df.empty:
                continue

            # Report progress
            if self._progress_callback:
                progress = (idx + 1) / total_samples
                self._progress_callback(
                    "merging_data",
                    progress,
                    {
                        "sample_id": row.get("sample_id", f"sample_{idx}"),
                        "sample_num": idx + 1,
                        "total_samples": total_samples,
                    },
                )

            # Create a copy to avoid modifying the original
            df = df.copy()

            # Add metadata columns from the sample row
            metadata_columns = [
                "sample_id",
                "mouse_id",
                "condition",
                "organ",
                "weight_mg",
            ]
            for col in metadata_columns:
                if col in row:
                    df[col] = row[col]

            # Convert weight_mg to numeric
            if "weight_mg" in df.columns:
                df["weight_mg"] = pd.to_numeric(df["weight_mg"], errors="coerce")

            # Calculate CPM per mg if weight is available
            if (
                "weight_mg" in df.columns
                and pd.notnull(df["weight_mg"].iloc[0])
                and df["weight_mg"].iloc[0] > 0
            ):
                df["CPM_per_mg"] = df["CPM"] / df["weight_mg"].iloc[0]
            else:
                df["CPM_per_mg"] = df["CPM"]  # fallback if no weight

            # Optionally recalculate CPM from Count if needed
            if "CPM" not in df.columns and "Count" in df.columns:
                total_counts = df["Count"].sum()
                if total_counts > 0:
                    df["CPM"] = (df["Count"] / total_counts) * self.cpm_scale
                    # Recalculate CPM_per_mg with the new CPM values
                    if (
                        "weight_mg" in df.columns
                        and pd.notnull(df["weight_mg"].iloc[0])
                        and df["weight_mg"].iloc[0] > 0
                    ):
                        df["CPM_per_mg"] = df["CPM"] / df["weight_mg"].iloc[0]
                    else:
                        df["CPM_per_mg"] = df["CPM"]

            all_rows.append(df)

        # Combine all samples
        if not all_rows:
            logging.warning("No valid sample data found.")
            return pd.DataFrame()

        merged = pd.concat(all_rows, ignore_index=True)

        # Report completion
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback(
                "merging_data", 1.0, {"total_samples": total_samples}
            )

        return merged

    def calculate_fold_change(
        self,
        merged: pd.DataFrame,
        input_data: Dict[str, pd.DataFrame],
        cpm_column: str = "CPM_per_mg",
        input_cpm_column: str = "CPM",
    ) -> pd.DataFrame:
        """Calculate log2 fold change vs. input reference for each sample.

        Parameters:
        -----------
        merged: pd.DataFrame
            Combined DataFrame with all samples
        input_data: Dict[str, pd.DataFrame]
            Dictionary mapping condition to input reference DataFrame
        cpm_column: str
            Column in merged to use for sample CPM values
        input_cpm_column: str
            Column in input_data to use for input CPM values

        Returns:
        --------
        pd.DataFrame
            DataFrame with additional log2FC_vs_input column
        """
        if merged.empty:
            return merged

        required_columns = {"Peptide", "condition", cpm_column}
        if not required_columns.issubset(merged.columns):
            missing = required_columns - set(merged.columns)
            raise ValueError(f"Merged DataFrame missing required columns: {missing}")

        # Initialize progress reporting
        total_rows = len(merged)
        if self._progress_callback:
            self._progress_callback(
                "calculating_fold_change", 0.0, {"total_rows": total_rows}
            )

        # Process in chunks for better memory efficiency and progress reporting
        chunk_size = min(
            10000, max(100, total_rows // 100)
        )  # Adjust based on dataset size
        fc_list = []

        # Process each chunk
        for i in range(0, total_rows, chunk_size):
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Fold change calculation cancelled by user")
                break

            # Get chunk
            end_idx = min(i + chunk_size, total_rows)
            chunk = merged.iloc[i:end_idx]

            # Report progress
            if self._progress_callback:
                progress = i / total_rows
                self._progress_callback(
                    "calculating_fold_change",
                    progress,
                    {"chunk": i // chunk_size + 1, "processed": i, "total": total_rows},
                )

            # Calculate fold change for each row in the chunk
            chunk_fc = []
            for idx, row in chunk.iterrows():
                peptide = row["Peptide"]
                cond = row["condition"]
                input_df = input_data.get(cond, pd.DataFrame())

                if input_df.empty or peptide not in input_df.index:
                    # No reference => set to NaN
                    fc = np.nan
                else:
                    # Get input CPM value
                    input_cpm = input_df.loc[peptide, input_cpm_column]

                    # Get sample CPM value
                    sample_cpm = row[cpm_column]

                    # Calculate fold change with pseudocount
                    fc = np.log2(
                        (sample_cpm + self.pseudocount) / (input_cpm + self.pseudocount)
                    )

                chunk_fc.append(fc)

            fc_list.extend(chunk_fc)

        # Add fold change values to the DataFrame
        if not self._cancel_flag:
            merged["log2FC_vs_input"] = fc_list

            # Report completion
            if self._progress_callback:
                self._progress_callback(
                    "calculating_fold_change", 1.0, {"total_rows": total_rows}
                )

        return merged

    def normalize_counts(
        self, df: pd.DataFrame, count_col: str = "Count"
    ) -> pd.DataFrame:
        """Normalize raw counts to CPM (Counts Per Million).

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame containing count data
        count_col: str
            Column containing raw counts

        Returns:
        --------
        pd.DataFrame
            DataFrame with additional CPM column
        """
        if df.empty or count_col not in df.columns:
            return df

        # Make a copy to avoid modifying the input
        result = df.copy()

        # Calculate total counts
        total_counts = result[count_col].sum()

        if total_counts > 0:
            # Calculate CPM
            result["CPM"] = (result[count_col] / total_counts) * self.cpm_scale
        else:
            # If no counts, set CPM to 0
            result["CPM"] = 0

        return result
