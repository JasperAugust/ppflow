"""FASTQ file preprocessing module.

This module provides functionality for preprocessing raw FASTQ files from
sequencers, including quality control, adapter trimming, read filtering, 
and conversion to count data.
"""

import os
import subprocess
import logging
import pandas as pd
import numpy as np
from Bio import SeqIO
from typing import Dict, List, Tuple, Optional, Union, Callable
import json
from Bio.Seq import Seq


class FastqPreprocessor:
    """Handles preprocessing of raw FASTQ files from sequencers."""

    def __init__(
        self,
        output_dir: str = "preprocessed",
        quality_threshold: int = 20,
        min_length: int = 10,
        adapter_sequence: Optional[str] = None,
        threads: int = 4,
        progress_callback: Optional[Callable] = None,
        seed_peptide: str = "MLGDPNS",  # Default to the M13 phage display seed peptide
        forward_constant: str = "",  # Empty by default in favor of seed peptide approach
        reverse_constant: str = "",  # Empty by default in favor of seed peptide approach
        use_position_fallback: bool = True,
        start_position: int = 30,
        peptide_length: int = 36,
    ):
        """Initialize the FastqPreprocessor.

        Args:
            output_dir: Directory to store processed files
            quality_threshold: Minimum quality threshold for reads
            min_length: Minimum length of reads after trimming
            adapter_sequence: Adapter sequence to trim
            threads: Number of threads to use for processing
            progress_callback: Callback function for progress updates
            seed_peptide: Peptide sequence to look for at start of variable regions (default: MLGDPNS for M13)
            forward_constant: Forward constant region flanking the variable region (optional)
            reverse_constant: Reverse constant region flanking the variable region (optional)
            use_position_fallback: Whether to fall back to position-based extraction
            start_position: Start position for position-based extraction
            peptide_length: Length of peptide region for position-based extraction
        """
        # Store parameters
        self.output_dir = output_dir
        self.quality_threshold = quality_threshold
        self.min_length = min_length
        self.adapter_sequence = adapter_sequence
        self.threads = threads
        self.progress_callback = progress_callback
        self.seed_peptide = seed_peptide
        self.forward_constant = forward_constant
        self.reverse_constant = reverse_constant
        self.use_position_fallback = use_position_fallback
        self.start_position = start_position
        self.peptide_length = peptide_length

        # Set up logging
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"Initializing FastqPreprocessor with output_dir={output_dir}")
        self.logger.info(f"Using seed peptide: {seed_peptide or 'None'}")
        if forward_constant and reverse_constant:
            self.logger.info(f"Forward constant: {forward_constant}")
            self.logger.info(f"Reverse constant: {reverse_constant}")
        if use_position_fallback:
            self.logger.info(
                f"Position fallback enabled (start={start_position}, length={peptide_length})"
            )

        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)

    def _report_progress(self, stage: str, progress: float, info: Dict = None) -> None:
        """Report progress to the callback function if provided."""
        if self.progress_callback:
            self.progress_callback(stage, progress, info or {})

    def preprocess_fastq(self, input_file: str, sample_id: str) -> str:
        """Preprocess a FASTQ file and return the path to the processed count data.

        Args:
            input_file: Path to input FASTQ file
            sample_id: Sample identifier for the file

        Returns:
            Path to the processed count data file (CSV)
        """
        self.logger.info(f"Preprocessing FASTQ file: {input_file}")
        self._report_progress(
            "preprocessing", 0.0, {"file": input_file, "sample_id": sample_id}
        )

        # Step 1: Quality control with FastQC
        self._run_fastqc(input_file)
        self._report_progress("preprocessing", 0.2)

        # Step 2: Adapter trimming and quality filtering with cutadapt
        trimmed_file = self._run_cutadapt(input_file, sample_id)
        self._report_progress("preprocessing", 0.4)

        # Step 3: Extract peptide sequences and generate count data
        count_file = self._generate_count_data(trimmed_file, sample_id)
        self._report_progress("preprocessing", 1.0)

        self.logger.info(f"Preprocessing complete for {input_file}")

        return count_file

    def _run_fastqc(self, fastq_file: str, output_dir: str) -> str:
        """Run FastQC on a FASTQ file.

        Args:
            fastq_file: Path to input FASTQ file
            output_dir: Directory to save FastQC output

        Returns:
            Path to the FastQC output directory
        """
        self.logger.info(f"Running FastQC on {fastq_file}")

        try:
            # Create FastQC output directory
            fastqc_dir = os.path.join(output_dir, "fastqc")
            os.makedirs(fastqc_dir, exist_ok=True)

            # Build FastQC command
            cmd = [
                "fastqc",
                "--outdir",
                fastqc_dir,
                "--threads",
                str(self.threads),
                "--quiet",
                fastq_file,
            ]

            # Run FastQC
            self.logger.debug(f"Running command: {' '.join(cmd)}")
            subprocess.run(
                cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )

            # Get the output HTML file path
            fastqc_html = os.path.join(
                fastqc_dir,
                os.path.basename(fastq_file).replace(".fastq", "_fastqc.html"),
            )

            self.logger.info(f"FastQC completed: {fastqc_html}")
            return fastqc_html

        except subprocess.CalledProcessError as e:
            self.logger.warning(
                f"FastQC failed: {e.stderr.decode() if e.stderr else str(e)}"
            )
            self.logger.warning("Continuing with processing despite FastQC failure")
            return ""
        except Exception as e:
            self.logger.warning(f"Error running FastQC: {str(e)}")
            self.logger.warning("Continuing with processing despite FastQC failure")
            return ""

    def _trim_adapters(self, fastq_file: str, output_dir: str) -> str:
        """Trim adapters and filter reads by quality.

        Args:
            fastq_file: Path to input FASTQ file
            output_dir: Directory to save trimmed output

        Returns:
            Path to the trimmed FASTQ file
        """
        self.logger.info(f"Trimming adapters from {fastq_file}")

        try:
            # Output file path
            trimmed_file = os.path.join(
                output_dir,
                os.path.basename(fastq_file).replace(".fastq", "_trimmed.fastq"),
            )

            # Build cutadapt command
            cmd = [
                "cutadapt",
                "-q",
                str(self.quality_threshold),
                "-m",
                str(self.min_length),
                "-j",
                str(self.threads),
                "-o",
                trimmed_file,
            ]

            # Add adapter sequence if provided
            if self.adapter_sequence:
                cmd.extend(["-a", self.adapter_sequence])

            # Add input file
            cmd.append(fastq_file)

            # Run cutadapt
            self.logger.debug(f"Running command: {' '.join(cmd)}")
            result = subprocess.run(
                cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )

            # Parse cutadapt summary
            output = result.stdout.decode()
            self.logger.info(f"Cutadapt completed: {os.path.basename(trimmed_file)}")

            # Extract some statistics (optional)
            reads_processed = 0
            reads_written = 0
            for line in output.split("\n"):
                if "Total reads processed:" in line:
                    reads_processed = int(line.split(":")[1].strip().replace(",", ""))
                elif "Reads written (passing filters):" in line:
                    reads_written = int(
                        line.split(":")[1].strip().split(" ")[0].replace(",", "")
                    )

            # Log statistics
            if reads_processed > 0:
                self.logger.info(f"Reads processed: {reads_processed}")
                self.logger.info(
                    f"Reads written: {reads_written} ({reads_written/reads_processed*100:.1f}%)"
                )

            return trimmed_file

        except subprocess.CalledProcessError as e:
            self.logger.error(
                f"Cutadapt failed: {e.stderr.decode() if e.stderr else str(e)}"
            )
            raise Exception(f"Failed to trim adapters: {str(e)}")
        except Exception as e:
            self.logger.error(f"Error trimming adapters: {str(e)}")
            raise Exception(f"Failed to trim adapters: {str(e)}")

    def _run_cutadapt(self, input_file: str, sample_id: str) -> str:
        """Run cutadapt for adapter trimming and quality filtering.

        Args:
            input_file: Path to input FASTQ file
            sample_id: Sample identifier for the file

        Returns:
            Path to trimmed FASTQ file
        """
        self.logger.info(
            f"Running adapter trimming and quality filtering on {input_file}"
        )

        trimmed_file = os.path.join(self.output_dir, f"{sample_id}_trimmed.fastq")

        cutadapt_cmd = [
            "cutadapt",
            "-q",
            str(self.quality_threshold),
            "--minimum-length",
            str(self.min_length),
            "-o",
            trimmed_file,
        ]

        # Add adapter sequence if provided
        if self.adapter_sequence:
            cutadapt_cmd.extend(["-a", self.adapter_sequence])

        # Add input file
        cutadapt_cmd.append(input_file)

        try:
            subprocess.run(cutadapt_cmd, check=True)
            self.logger.info(f"Adapter trimming completed for {input_file}")
        except FileNotFoundError:
            self.logger.error("cutadapt not found. Cannot perform adapter trimming.")
            raise RuntimeError("cutadapt tool is required but not found")
        except subprocess.CalledProcessError as e:
            self.logger.error(f"cutadapt failed: {e}")
            raise RuntimeError(f"cutadapt processing failed: {e}")

        return trimmed_file

    def _generate_count_data(self, trimmed_fastq: str, output_path: str) -> str:
        """Generate count data from trimmed FASTQ file.

        For phage display libraries, this uses multiple strategies for peptide extraction:
        1. Seed Peptide Search: Find DNA sequences that translate to MLGDPNS and extract the peptide after it
        2. Position-based fallback: Extract peptides at fixed positions

        Args:
            trimmed_fastq: Path to trimmed FASTQ file
            output_path: Directory to save output files

        Returns:
            Path to the generated count file
        """
        try:
            # Use .csv extension for compatibility with the data loader
            count_file = os.path.join(
                output_path,
                os.path.basename(trimmed_fastq).replace(".fastq", "_counts.csv"),
            )
            counts = {}

            # Statistics for reporting
            total_reads = 0
            extracted_peptides = 0
            failed_extractions = 0
            extraction_methods = {"seed": 0, "position": 0}

            self.logger.info(f"Generating count data from {trimmed_fastq}")
            self.logger.info(f"Using seed peptide: {self.seed_peptide or 'None'}")

            # DNA codons for MLGDPNS (multiple possibilities due to codon degeneracy)
            # This helps with direct DNA matching without translation
            if self.seed_peptide == "MLGDPNS":
                self.logger.info("Using optimized search for MLGDPNS seed peptide")
                # M: ATG
                # L: TTA, TTG, CTT, CTC, CTA, CTG
                # G: GGT, GGC, GGA, GGG
                # D: GAT, GAC
                # P: CCT, CCC, CCA, CCG
                # N: AAT, AAC
                # S: TCT, TCC, TCA, TCG, AGT, AGC

                # Most common codon combinations for MLGDPNS in phage display
                seed_dna_patterns = [
                    "ATGCTGGGTGATCCGAATTCT",  # MLGDPNS
                    "ATGCTGGGCGATCCGAACTCG",  # MLGDPNS variant
                    "ATGTTGGGCGATCCAAACTCT",  # MLGDPNS variant
                ]
            else:
                seed_dna_patterns = []

            with open(trimmed_fastq, "r") as f:
                # FASTQ format has 4 lines per read
                lines = []
                for line in f:
                    lines.append(line.strip())
                    if len(lines) == 4:
                        # Process the read
                        total_reads += 1
                        seq = lines[1]
                        peptide = None
                        extraction_method = None

                        # Method 1: Search for MLGDPNS seed peptide optimized pattern
                        if self.seed_peptide == "MLGDPNS" and seed_dna_patterns:
                            for pattern in seed_dna_patterns:
                                pattern_pos = seq.find(pattern)
                                if pattern_pos >= 0:
                                    # Find the end of the seed peptide DNA
                                    extract_start = pattern_pos + len(pattern)

                                    # Extract the variable region after the seed (up to 60 bases)
                                    max_extract_len = min(60, len(seq) - extract_start)
                                    variable_dna = seq[
                                        extract_start : extract_start + max_extract_len
                                    ]

                                    # Make sure length is multiple of 3 for proper translation
                                    variable_dna = (
                                        variable_dna[: -(len(variable_dna) % 3)]
                                        if len(variable_dna) % 3 != 0
                                        else variable_dna
                                    )

                                    if variable_dna:
                                        # Translate to amino acids
                                        peptide = self.dna2aa(variable_dna)
                                        if peptide and "*" not in peptide:
                                            extraction_method = "seed"
                                            break

                        # Method 2: Try all reading frames if seed pattern direct search didn't work
                        if not peptide and self.seed_peptide:
                            # Find potential ORFs in all reading frames and both strands
                            positions = self.find_seed_positions(seq)

                            for start_pos, frame, strand in positions:
                                # Get the sequence to translate
                                sequence_to_translate = seq
                                if strand == "reverse":
                                    sequence_to_translate = self.reverse_complement(seq)

                                # Extract ORF from the position
                                dna_seq = self.extract_orf(
                                    sequence_to_translate, start_pos
                                )

                                # Translate to amino acids
                                aa_seq = self.dna2aa(dna_seq)

                                # Check if it contains the seed peptide
                                if aa_seq and self.seed_peptide in aa_seq:
                                    # Find the seed position
                                    seed_pos = aa_seq.find(self.seed_peptide)
                                    # Extract the peptide after the seed
                                    peptide_after_seed = aa_seq[
                                        seed_pos + len(self.seed_peptide) :
                                    ]

                                    # Remove everything after first stop codon
                                    stop_pos = peptide_after_seed.find("*")
                                    if stop_pos != -1:
                                        peptide_after_seed = peptide_after_seed[
                                            :stop_pos
                                        ]

                                    # Use peptide if it's not empty
                                    if peptide_after_seed:
                                        peptide = peptide_after_seed
                                        extraction_method = "seed"
                                        break

                        # Method 3: Position-based extraction (fallback)
                        if not peptide and self.use_position_fallback:
                            if len(seq) >= self.start_position + self.peptide_length:
                                dna_seq = seq[
                                    self.start_position : self.start_position
                                    + self.peptide_length
                                ]
                                # Validate the length (must be multiple of 3 for codons)
                                if len(dna_seq) % 3 == 0:
                                    peptide = self.dna2aa(dna_seq)
                                    if peptide and "*" not in peptide:
                                        extraction_method = "position"

                        # Count the peptide if extraction was successful
                        if (
                            peptide and "*" not in peptide
                        ):  # Skip peptides with stop codons
                            extracted_peptides += 1
                            if extraction_method:
                                extraction_methods[extraction_method] += 1
                            counts[peptide] = counts.get(peptide, 0) + 1
                        else:
                            failed_extractions += 1

                        # Reset for next read
                        lines = []

                        # Report progress
                        if self.progress_callback and total_reads % 10000 == 0:
                            self.progress_callback(
                                f"Processed {total_reads} reads, extracted {extracted_peptides} peptides"
                            )

            # Calculate CPM (Counts Per Million)
            total_count = sum(counts.values())
            cpm_factor = 1000000 / total_count if total_count > 0 else 0

            # Log results
            self.logger.info(f"Total reads processed: {total_reads}")
            self.logger.info(f"Extracted peptides: {extracted_peptides}")
            self.logger.info(f"Failed extractions: {failed_extractions}")
            self.logger.info(f"Unique peptides found: {len(counts)}")
            if extraction_methods["seed"] > 0:
                self.logger.info(
                    f"Seed-based extractions: {extraction_methods['seed']}"
                )
            if extraction_methods["position"] > 0:
                self.logger.info(
                    f"Position-based extractions: {extraction_methods['position']}"
                )

            # Write statistics to a JSON file for quality control
            stats_file = os.path.join(
                output_path,
                os.path.basename(trimmed_fastq).replace(".fastq", "_stats.json"),
            )
            with open(stats_file, "w") as f:
                json.dump(
                    {
                        "total_reads": total_reads,
                        "extracted_peptides": extracted_peptides,
                        "failed_extractions": failed_extractions,
                        "unique_peptides": len(counts),
                        "extraction_rate": (
                            (extracted_peptides / total_reads) if total_reads > 0 else 0
                        ),
                        "seed_extractions": extraction_methods["seed"],
                        "position_extractions": extraction_methods["position"],
                    },
                    f,
                    indent=2,
                )

            # Write count data to file with expected column names: Peptide,CPM,Count (CSV format)
            with open(count_file, "w") as f:
                f.write("Peptide,CPM,Count\n")
                for peptide, count in sorted(
                    counts.items(), key=lambda x: x[1], reverse=True
                ):
                    cpm = count * cpm_factor
                    f.write(f"{peptide},{cpm:.2f},{count}\n")

            # If no peptides were found, still create a valid file but log a warning
            if not counts:
                self.logger.warning(f"No peptides extracted from {trimmed_fastq}")
                self.logger.warning(
                    f"Check if you're using the correct seed peptide: {self.seed_peptide}"
                )
                # Write just the header to ensure a valid empty file
                with open(count_file, "w") as f:
                    f.write("Peptide,CPM,Count\n")

            return count_file

        except Exception as e:
            self.logger.error(f"Error generating count data: {str(e)}")
            # Create an empty file to prevent downstream errors
            with open(count_file, "w") as f:
                f.write("Peptide,CPM,Count\n")
            return count_file

    def batch_process(self, input_files: Dict[str, str]) -> Dict[str, str]:
        """Process a batch of FASTQ files.

        Args:
            input_files: Dictionary mapping sample IDs to file paths

        Returns:
            Dictionary with sample IDs and paths to their count files
        """
        results = {}
        total_files = len(input_files)

        self.logger.info(f"Starting batch processing of {total_files} FASTQ files")

        for i, (sample_id, file_path) in enumerate(input_files.items(), 1):
            try:
                self.logger.info(f"Processing file {i}/{total_files}: {sample_id}")

                if self.progress_callback:
                    self.progress_callback(
                        f"Processing {sample_id} ({i}/{total_files})"
                    )

                # Process the file
                file_results = self.preprocess_single_file(file_path, sample_id)

                # Store the count file path in results
                results[sample_id] = file_results["counts"]

                if self.progress_callback:
                    self.progress_callback(f"Completed {i}/{total_files} files")

            except Exception as e:
                self.logger.error(f"Error processing {sample_id}: {str(e)}")
                # Create a placeholder for failed samples
                results[sample_id] = None

        self.logger.info(
            f"Completed batch processing, processed {len(results)} samples"
        )
        return results

    def preprocess_single_file(
        self, input_file: str, sample_id: str = None
    ) -> Dict[str, str]:
        """Preprocess a single FASTQ file.

        Args:
            input_file: Path to input FASTQ file
            sample_id: Sample identifier (defaults to filename without extension)

        Returns:
            Dictionary with paths to preprocessed files
        """
        if sample_id is None:
            sample_id = os.path.splitext(os.path.basename(input_file))[0]

        self.logger.info(f"Preprocessing {input_file} (sample_id: {sample_id})")

        # Create sample-specific output directory
        sample_output_dir = os.path.join(self.output_dir, sample_id)
        os.makedirs(sample_output_dir, exist_ok=True)

        result_files = {}

        try:
            # Step 1: Run FastQC for quality assessment
            result_files["fastqc"] = self._run_fastqc(input_file, sample_output_dir)

            # Step 2: Trim adapters and filter by quality
            trimmed_file = self._trim_adapters(input_file, sample_output_dir)
            result_files["trimmed"] = trimmed_file

            # Step 3: Generate peptide count data
            counts_file = self._generate_count_data(trimmed_file, sample_output_dir)
            result_files["counts"] = counts_file

            self.logger.info(f"Completed preprocessing for {sample_id}")

            return result_files

        except Exception as e:
            self.logger.error(f"Error preprocessing {input_file}: {str(e)}")
            if "counts" not in result_files:
                # Create an empty counts file if it doesn't exist yet
                counts_file = os.path.join(sample_output_dir, f"{sample_id}_counts.csv")
                with open(counts_file, "w") as f:
                    f.write("Peptide,CPM,Count\n")
                result_files["counts"] = counts_file

            # Create error file with details
            error_file = os.path.join(sample_output_dir, f"{sample_id}_error.txt")
            with open(error_file, "w") as f:
                f.write(f"Error preprocessing {input_file}:\n{str(e)}")
            result_files["error"] = error_file

            # Create minimal statistics file
            stats_file = os.path.join(sample_output_dir, f"{sample_id}_stats.json")
            with open(stats_file, "w") as f:
                json.dump(
                    {
                        "error": str(e),
                        "total_reads": 0,
                        "extracted_peptides": 0,
                        "completed": False,
                    },
                    f,
                    indent=2,
                )
            result_files["stats"] = stats_file

            raise Exception(f"Preprocessing failed for {input_file}: {str(e)}")

    def process_fastq_to_counts(
        self, fastq_files: List[str], sample_ids: Optional[List[str]] = None
    ) -> Dict[str, str]:
        """Process FASTQ files to peptide count data.

        Args:
            fastq_files: List of FASTQ file paths
            sample_ids: Optional list of sample IDs (if None, filenames are used)

        Returns:
            Dictionary mapping sample IDs to count file paths
        """
        if sample_ids is None:
            sample_ids = [os.path.splitext(os.path.basename(f))[0] for f in fastq_files]

        if len(sample_ids) != len(fastq_files):
            raise ValueError("Number of sample IDs must match number of FASTQ files")

        # Create input_files dictionary
        input_files = {
            sample_id: file_path
            for sample_id, file_path in zip(sample_ids, fastq_files)
        }

        # Process files
        return self.batch_process(input_files)

    def preprocess(
        self, fastq_files: Union[str, List[str]], output_dir: Optional[str] = None
    ) -> Dict[str, str]:
        """Preprocess FASTQ files and extract peptide counts.

        This is the main entry point for preprocessing FASTQ files from phage display experiments.

        Args:
            fastq_files: Path to a FASTQ file or list of FASTQ file paths
            output_dir: Directory to store preprocessed files (if None, uses self.output_dir)

        Returns:
            Dictionary mapping sample IDs to count file paths
        """
        # Handle a single file case
        if isinstance(fastq_files, str):
            fastq_files = [fastq_files]

        # Set output directory
        original_output_dir = self.output_dir
        if output_dir:
            self.output_dir = output_dir
            os.makedirs(output_dir, exist_ok=True)

        self.logger.info(f"Starting preprocessing of {len(fastq_files)} FASTQ files")
        self.logger.info(f"Output directory: {self.output_dir}")
        self.logger.info(f"Phage display library parameters:")
        self.logger.info(f"  Forward constant: {self.forward_constant}")
        self.logger.info(f"  Reverse constant: {self.reverse_constant}")
        self.logger.info(f"  Use position fallback: {self.use_position_fallback}")
        if self.use_position_fallback:
            self.logger.info(f"  Start position: {self.start_position}")
            self.logger.info(f"  Peptide length: {self.peptide_length}")

        try:
            # Process files
            result = self.process_fastq_to_counts(fastq_files)

            # Log summary
            successful = sum(1 for path in result.values() if path is not None)
            self.logger.info(
                f"Preprocessing completed: {successful}/{len(fastq_files)} files processed successfully"
            )

            return result

        except Exception as e:
            self.logger.error(f"Error during preprocessing: {str(e)}")
            raise

        finally:
            # Restore original output directory
            if output_dir:
                self.output_dir = original_output_dir

    def dna2aa(self, sequence: str) -> str:
        """Translate DNA sequence to amino acid sequence.

        Args:
            sequence: DNA sequence to translate

        Returns:
            Translated amino acid sequence with stop codons represented as '*'
        """
        try:
            # Ensure the sequence length is a multiple of 3
            if len(sequence) % 3 != 0:
                # Trim to the nearest multiple of 3
                sequence = sequence[: -(len(sequence) % 3)]

            if not sequence:
                return ""

            # Translate using Biopython
            amino_acid_seq = str(Seq(sequence).translate())

            # Replace any underscores (Bio.Seq's stop codon representation) with asterisks
            # This makes it consistent with the common '*' representation
            amino_acid_seq = amino_acid_seq.replace("_", "*")

            return amino_acid_seq
        except Exception as e:
            self.logger.warning(f"Error translating DNA sequence: {str(e)}")
            return ""

    def reverse_complement(self, sequence: str) -> str:
        """Generate the reverse complement of a DNA sequence.

        Args:
            sequence: DNA sequence

        Returns:
            Reverse complement sequence
        """
        try:
            return str(Seq(sequence).reverse_complement())
        except Exception as e:
            self.logger.warning(f"Error generating reverse complement: {str(e)}")
            return ""

    def find_seed_positions(self, sequence: str) -> list:
        """Find potential positions where ORFs might start.

        This searches for ATG start codons in all frames and both strands.

        Args:
            sequence: DNA sequence to search

        Returns:
            List of (position, frame, strand) tuples where translatable regions start
        """
        positions = []

        # Check forward strand in all 3 frames
        for frame in range(3):
            start = frame
            while start + 3 <= len(sequence):
                codon = sequence[start : start + 3]
                # Check if this is a valid start codon (ATG)
                if codon == "ATG":
                    positions.append((start, frame, "forward"))
                start += 3

        # Check reverse strand in all 3 frames
        rev_seq = self.reverse_complement(sequence)
        if rev_seq:
            for frame in range(3):
                start = frame
                while start + 3 <= len(rev_seq):
                    codon = rev_seq[start : start + 3]
                    # Check if this is a valid start codon (ATG)
                    if codon == "ATG":
                        positions.append((start, frame, "reverse"))
                    start += 3

        return positions

    def extract_orf(self, sequence: str, start_pos: int) -> str:
        """Extract open reading frame starting at a specific position.

        Args:
            sequence: DNA sequence
            start_pos: Start position of the ORF

        Returns:
            DNA sequence of the ORF (from start to stop codon or end of sequence)
        """
        # Ensure start_pos is a multiple of 3 (codon boundary)
        start_pos = start_pos - (start_pos % 3)

        # Find the next stop codon
        i = start_pos
        while i <= len(sequence) - 3:
            codon = sequence[i : i + 3]
            # Stop codons: TAA, TAG, TGA
            if codon in ["TAA", "TAG", "TGA"]:
                return sequence[start_pos : i + 3]
            i += 3

        # If no stop codon found, return the rest of the sequence
        return sequence[start_pos:]
