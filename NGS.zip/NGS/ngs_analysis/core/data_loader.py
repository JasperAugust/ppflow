"""Data loading and validation module.

This module handles all file I/O operations, validates input data formats,
and implements chunked reading for large files.
"""

import os
import gc
import logging
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union

from ..utils.validators import ValidationError


class DataLoader:
    """Handles loading and validation of input sequence data."""

    def __init__(self, config=None):
        self.config = config or {}
        self._progress_callback = None
        self._cancel_flag = False

    def set_progress_callback(self, callback):
        """Set callback function for progress updates."""
        self._progress_callback = callback

    def set_cancel_flag(self, flag):
        """Set flag to request cancellation of operations."""
        self._cancel_flag = flag

    def read_design_file(self, design_file_path: str) -> pd.DataFrame:
        """Read the experiment design file that contains metadata about samples.

        Parameters:
        -----------
        design_file_path: str
            Path to CSV file containing experiment design information

        Returns:
        --------
        pd.DataFrame
            DataFrame containing design information with columns like
            sample_id, condition, organ, file_path, etc.

        Raises:
        -------
        ValidationError: If the design file is missing required columns
        FileNotFoundError: If the design file doesn't exist
        """
        if not os.path.exists(design_file_path):
            raise FileNotFoundError(f"Design file not found: {design_file_path}")

        # Signal progress start
        if self._progress_callback:
            self._progress_callback(
                "reading_design_file", 0.0, {"file": design_file_path}
            )

        try:
            # Read the design file
            design_df = pd.read_csv(design_file_path, comment="#")

            # Check for cancellation
            if self._cancel_flag:
                raise ValueError("Operation cancelled by user")

            # Validate required columns for all samples
            required_columns = {"sample_id", "file_path", "role"}
            missing = required_columns - set(design_df.columns)
            if missing:
                raise ValidationError(
                    f"Design file missing required columns: {', '.join(missing)}"
                )

            # Validate that role values are valid
            valid_roles = {"Input", "Sample", "Reference"}
            invalid_roles = set(design_df["role"].unique()) - valid_roles
            if invalid_roles:
                raise ValidationError(
                    f"Invalid role values found: {', '.join(invalid_roles)}. "
                    f"Valid values are: {', '.join(valid_roles)}"
                )

            # For Sample roles, additional columns are required
            sample_rows = design_df[design_df["role"] == "Sample"]
            if not sample_rows.empty:
                sample_required_columns = {"condition", "organ", "mouse_id"}
                missing_sample_columns = sample_required_columns - set(
                    design_df.columns
                )
                if missing_sample_columns:
                    raise ValidationError(
                        f"Design file missing required columns for Sample rows: {', '.join(missing_sample_columns)}"
                    )

                # Check if any Sample rows have empty values for required fields
                for col in sample_required_columns:
                    if col in design_df.columns and sample_rows[col].isnull().any():
                        raise ValidationError(
                            f"Column '{col}' has missing values for Sample rows"
                        )

            # Fill missing/NA values with placeholders for Input/Reference roles
            for col in ["condition", "organ", "mouse_id"]:
                if col in design_df.columns:
                    # Only fill NA values in rows where role is not 'Sample'
                    mask = (design_df["role"] != "Sample") & design_df[col].isnull()
                    if mask.any():
                        design_df.loc[mask, col] = "NA"

            # Signal progress completion
            if self._progress_callback:
                self._progress_callback(
                    "reading_design_file", 1.0, {"file": design_file_path}
                )

            return design_df

        except Exception as e:
            if not isinstance(e, (ValidationError, ValueError)):
                # Wrap the exception with more context
                raise ValidationError(f"Error reading design file: {str(e)}") from e
            raise

    def read_peptide_file(
        self, file_path: str, chunk_size: int = 10000
    ) -> pd.DataFrame:
        """Read peptide data with chunking support and progress reporting.

        Parameters:
        -----------
        file_path: str
            Path to the peptide file (CSV)
        chunk_size: int
            Number of rows to read at once (for large files)

        Returns:
        --------
        pd.DataFrame
            DataFrame containing peptide data with columns Peptide, Count, CPM

        Raises:
        -------
        ValidationError: If the file is missing required columns
        FileNotFoundError: If the file doesn't exist
        """
        # Check if file exists
        if not os.path.exists(file_path):
            logging.warning(f"File {file_path} not found. Returning empty DataFrame.")
            return pd.DataFrame()

        # Signal progress start
        if self._progress_callback:
            self._progress_callback("reading_peptide_file", 0.0, {"file": file_path})

        try:
            # For small files or if chunking is disabled, read the whole file at once
            if chunk_size <= 0:
                df = pd.read_csv(file_path)

                # Ensure required columns exist
                required_columns = {"Peptide", "Count", "CPM"}
                missing = required_columns - set(df.columns)
                if missing:
                    logging.warning(
                        f"File {file_path} missing required columns: {', '.join(missing)}. "
                        "Returning empty DataFrame."
                    )
                    return pd.DataFrame()

                # Report progress completion
                if self._progress_callback:
                    self._progress_callback(
                        "reading_peptide_file", 1.0, {"file": file_path}
                    )

                return df

            # For large files, use chunking
            # First determine total size for progress reporting
            total_size = os.path.getsize(file_path)
            processed_size = 0
            chunks = []

            # Read the first chunk to validate columns
            try:
                first_chunk = pd.read_csv(
                    file_path, nrows=10
                )  # Read just a few rows to check columns

                # Ensure required columns exist
                required_columns = {"Peptide", "Count", "CPM"}
                missing = required_columns - set(first_chunk.columns)
                if missing:
                    logging.warning(
                        f"File {file_path} missing required columns: {', '.join(missing)}. "
                        "Returning empty DataFrame."
                    )
                    return pd.DataFrame()

            except Exception as e:
                logging.warning(f"Error reading file header {file_path}: {str(e)}")
                return pd.DataFrame()

            # Now read the file in chunks
            for i, chunk in enumerate(pd.read_csv(file_path, chunksize=chunk_size)):
                # Check for cancellation
                if self._cancel_flag:
                    logging.info(f"Reading file {file_path} cancelled by user")
                    return pd.DataFrame()

                chunks.append(chunk)

                # Update progress
                chunk_size_bytes = (
                    len(chunk) * chunk.memory_usage(index=True, deep=False).mean()
                )
                processed_size += chunk_size_bytes
                if self._progress_callback:
                    progress = min(processed_size / total_size, 1.0)
                    self._progress_callback(
                        "reading_peptide_file",
                        progress,
                        {"file": file_path, "chunk": i},
                    )

            # Combine all chunks
            if chunks:
                result = pd.concat(chunks, ignore_index=True)

                # Clean up memory
                del chunks
                gc.collect()

                # Report progress completion
                if self._progress_callback:
                    self._progress_callback(
                        "reading_peptide_file", 1.0, {"file": file_path}
                    )

                return result
            else:
                return pd.DataFrame()

        except Exception as e:
            logging.warning(f"Error reading file {file_path}: {str(e)}")
            return pd.DataFrame()

    def read_all_peptide_files(self, design_df: pd.DataFrame) -> pd.DataFrame:
        """Read all peptide files referenced in the design DataFrame

        Parameters:
        -----------
        design_df: pd.DataFrame
            DataFrame containing experiment design with file_path column

        Returns:
        --------
        pd.DataFrame
            Same as input design_df but with an additional 'data' column
            containing the peptide data for each sample
        """
        if "file_path" not in design_df.columns:
            raise ValidationError("Design DataFrame must contain 'file_path' column")

        # Make a copy to avoid modifying the input
        result_df = design_df.copy()

        # Initialize progress reporting
        total_files = len(design_df)
        if self._progress_callback:
            self._progress_callback(
                "reading_all_files", 0.0, {"total_files": total_files}
            )

        # Read each file
        data_list = []
        for i, row in design_df.iterrows():
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Reading all peptide files cancelled by user")
                break

            file_path = row["file_path"]

            # Report progress on individual file
            if self._progress_callback:
                self._progress_callback(
                    "reading_all_files",
                    i / total_files,
                    {"file": file_path, "file_num": i + 1, "total_files": total_files},
                )

            # Read the file
            df = self.read_peptide_file(file_path)
            data_list.append(df)

        # Add data to the result DataFrame
        result_df["data"] = data_list

        # Report completion
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback(
                "reading_all_files", 1.0, {"total_files": total_files}
            )

        return result_df

    def prepare_input_references(
        self, input_df: pd.DataFrame
    ) -> Dict[str, pd.DataFrame]:
        """Prepare input reference data for each condition

        Parameters:
        -----------
        input_df: pd.DataFrame
            DataFrame containing input samples (filtered from design_df)

        Returns:
        --------
        Dict[str, pd.DataFrame]
            Dictionary mapping condition to input reference DataFrame
        """
        input_data = {}

        # Initialize progress
        conditions = input_df["condition"].unique()
        total_conditions = len(conditions)
        if self._progress_callback:
            self._progress_callback(
                "preparing_input_refs", 0.0, {"total_conditions": total_conditions}
            )

        # Process each condition
        for i, cond in enumerate(conditions):
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Preparing input references cancelled by user")
                break

            subset = input_df[input_df["condition"] == cond]

            # Report progress
            if self._progress_callback:
                self._progress_callback(
                    "preparing_input_refs",
                    i / total_conditions,
                    {
                        "condition": cond,
                        "condition_num": i + 1,
                        "total_conditions": total_conditions,
                    },
                )

            # If no input for this condition
            if len(subset) == 0:
                logging.warning(f"No input file found for condition={cond}.")
                input_data[cond] = pd.DataFrame()
                continue

            # If there's more than one row labeled as input for the same condition,
            # you can decide if you want to average them or pick one.
            # For simplicity, assume exactly 1 input file per condition.
            row = subset.iloc[0]
            df = row["data"]
            if df.empty:
                logging.warning(f"No data in input file for condition={cond}.")

            input_data[cond] = df.copy()

            # Re-index by Peptide for quick lookups
            if not df.empty and "Peptide" in df.columns:
                input_data[cond].set_index("Peptide", inplace=True, drop=False)

        # Report completion
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback(
                "preparing_input_refs", 1.0, {"total_conditions": total_conditions}
            )

        return input_data
