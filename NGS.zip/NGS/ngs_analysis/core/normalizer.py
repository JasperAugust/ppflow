"""Normalization module.

This module handles various normalization methods for phage display data,
including CPM normalization, fold change calculations, and control-based normalization.
"""

import numpy as np
import pandas as pd
import logging
from typing import Dict, List, Optional, Tuple, Union


class Normalizer:
    """Handles data normalization for phage display analysis."""

    def __init__(self, config=None):
        self.config = config or {}
        self._progress_callback = None
        self._cancel_flag = False

        # Default configuration
        self.pseudocount = self.config.get("pseudocount", 1.0)
        self.cpm_scale = self.config.get("cpm_scale", 1e6)

    def set_progress_callback(self, callback):
        """Set callback function for progress updates."""
        self._progress_callback = callback

    def set_cancel_flag(self, flag):
        """Set flag to request cancellation of operations."""
        self._cancel_flag = flag

    def calculate_fold_change(self, data_df: pd.DataFrame) -> pd.DataFrame:
        """Calculate fold change between conditions.

        Parameters:
        -----------
        data_df: pd.DataFrame
            DataFrame containing peptide data

        Returns:
        --------
        pd.DataFrame
            DataFrame with fold change values
        """
        # Implementation will be based on specific needs
        return data_df

    def compute_fold_over_control(
        self,
        data_df: pd.DataFrame,
        control_peptide: str = "GGGGGGG",
        cpm_col: str = "CPM_per_mg",
        pseudocount: Optional[float] = None,
    ) -> pd.DataFrame:
        """Calculate fold change relative to a control peptide.

        Parameters:
        -----------
        data_df: pd.DataFrame
            DataFrame containing peptide data
        control_peptide: str
            Peptide to use as control (default: CGGGGGGGC)
        cpm_col: str
            Column containing CPM values (default: CPM_per_mg)
        pseudocount: float
            Small value to avoid division by zero (default: from class config)

        Returns:
        --------
        pd.DataFrame
            DataFrame with fold over control values
        """
        if data_df.empty:
            return data_df

        # Check if required columns exist
        required_columns = {"Peptide", cpm_col}
        if not required_columns.issubset(data_df.columns):
            missing = required_columns - set(data_df.columns)
            raise ValueError(f"DataFrame missing required columns: {missing}")

        # Initialize progress
        if self._progress_callback:
            self._progress_callback(
                "fold_over_control", 0.0, {"control": control_peptide}
            )

        # Use class pseudocount if none provided
        if pseudocount is None:
            pseudocount = self.pseudocount

        # Make a copy to avoid modifying the input
        result_df = data_df.copy()

        # Process data in batches for efficiency with large datasets
        # Group by condition, organ, mouse_id or other relevant factors
        if "condition" in result_df.columns and "organ" in result_df.columns:
            # Group by condition and organ
            groups = result_df.groupby(["condition", "organ"])
        elif "condition" in result_df.columns:
            # Group by condition only
            groups = result_df.groupby(["condition"])
        else:
            # No grouping, process all at once
            groups = [(None, result_df)]

        # Initialize progress tracking
        total_groups = len(groups)
        processed_groups = 0

        # Process each group
        fold_values = []

        for group_key, group_df in groups:
            # Check for cancellation
            if self._cancel_flag:
                logging.info("Fold over control calculation cancelled by user")
                break

            # Update progress
            if self._progress_callback:
                progress = processed_groups / total_groups
                self._progress_callback(
                    "fold_over_control",
                    progress,
                    {
                        "group": group_key,
                        "processed": processed_groups,
                        "total": total_groups,
                    },
                )

            # Find the control peptide in this group
            control_rows = group_df[group_df["Peptide"] == control_peptide]

            if control_rows.empty:
                logging.warning(
                    f"Control peptide {control_peptide} not found in group {group_key}. Skipping."
                )
                # Set fold over control to NaN for this group
                group_df["fold_over_control"] = np.nan
                fold_values.append(group_df)
                processed_groups += 1
                continue

            # Get mean CPM for control
            control_cpm = control_rows[cpm_col].mean()

            if pd.isna(control_cpm) or control_cpm == 0:
                logging.warning(
                    f"Control peptide has zero or NaN value in group {group_key}. Using pseudocount."
                )
                control_cpm = pseudocount

            # Calculate fold over control
            group_df = group_df.copy()
            group_df["fold_over_control"] = (group_df[cpm_col] + pseudocount) / (
                control_cpm + pseudocount
            )

            # Also calculate log2 fold change
            group_df["log2_fold_over_control"] = np.log2(group_df["fold_over_control"])

            fold_values.append(group_df)
            processed_groups += 1

        # Combine results
        if fold_values:
            result_df = pd.concat(fold_values, ignore_index=True)
        else:
            # If no results, add empty columns
            result_df["fold_over_control"] = np.nan
            result_df["log2_fold_over_control"] = np.nan

        # Complete progress
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback("fold_over_control", 1.0, {})

        return result_df

    def normalize_counts_to_cpm(
        self,
        data_df: pd.DataFrame,
        count_col: str = "Count",
        scale: Optional[float] = None,
    ) -> pd.DataFrame:
        """Normalize raw counts to Counts Per Million (CPM).

        Parameters:
        -----------
        data_df: pd.DataFrame
            DataFrame containing raw count data
        count_col: str
            Column containing raw counts (default: Count)
        scale: float
            Scale factor for CPM (default: from class config)

        Returns:
        --------
        pd.DataFrame
            DataFrame with added CPM column
        """
        if data_df.empty:
            return data_df

        # Check if required columns exist
        if count_col not in data_df.columns:
            raise ValueError(f"Count column '{count_col}' not found in DataFrame")

        # Use class scale if none provided
        if scale is None:
            scale = self.cpm_scale

        # Make a copy to avoid modifying the input
        result_df = data_df.copy()

        # Initialize progress
        if self._progress_callback:
            self._progress_callback("normalize_cpm", 0.0, {})

        # Process data in batches for efficiency with large datasets
        # Group by sample or other relevant factors if present
        if "sample_id" in result_df.columns:
            # Group by sample_id
            groups = result_df.groupby(["sample_id"])
        else:
            # No grouping, process all at once
            groups = [(None, result_df)]

        # Initialize progress tracking
        total_groups = len(groups)
        processed_groups = 0

        # Process each group
        normalized_dfs = []

        for group_key, group_df in groups:
            # Check for cancellation
            if self._cancel_flag:
                logging.info("CPM normalization cancelled by user")
                break

            # Update progress
            if self._progress_callback:
                progress = processed_groups / total_groups
                self._progress_callback(
                    "normalize_cpm",
                    progress,
                    {
                        "group": group_key,
                        "processed": processed_groups,
                        "total": total_groups,
                    },
                )

            # Get total counts for this group
            total_counts = group_df[count_col].sum()

            if total_counts == 0:
                logging.warning(
                    f"Total counts is zero for group {group_key}. Setting CPM to 0."
                )
                group_df = group_df.copy()
                group_df["CPM"] = 0
                normalized_dfs.append(group_df)
                processed_groups += 1
                continue

            # Calculate CPM
            group_df = group_df.copy()
            group_df["CPM"] = (group_df[count_col] / total_counts) * scale

            normalized_dfs.append(group_df)
            processed_groups += 1

        # Combine results
        if normalized_dfs:
            result_df = pd.concat(normalized_dfs, ignore_index=True)
        else:
            # If no results, add empty CPM column
            result_df["CPM"] = np.nan

        # Complete progress
        if self._progress_callback and not self._cancel_flag:
            self._progress_callback("normalize_cpm", 1.0, {})

        return result_df

    def normalize_by_tissue_weight(
        self, data_df: pd.DataFrame, cpm_col: str = "CPM", weight_col: str = "weight_mg"
    ) -> pd.DataFrame:
        """Normalize CPM by tissue weight.

        Parameters:
        -----------
        data_df: pd.DataFrame
            DataFrame containing CPM data
        cpm_col: str
            Column containing CPM values (default: CPM)
        weight_col: str
            Column containing tissue weights (default: weight_mg)

        Returns:
        --------
        pd.DataFrame
            DataFrame with added CPM_per_mg column
        """
        if data_df.empty:
            return data_df

        # Check if required columns exist
        required_columns = {cpm_col, weight_col}
        if not required_columns.issubset(data_df.columns):
            missing = required_columns - set(data_df.columns)
            raise ValueError(f"DataFrame missing required columns: {missing}")

        # Make a copy to avoid modifying the input
        result_df = data_df.copy()

        # Initialize progress
        if self._progress_callback:
            self._progress_callback("normalize_weight", 0.0, {})

        # Convert weight to numeric if it's not already
        if result_df[weight_col].dtype not in ["int64", "float64"]:
            result_df[weight_col] = pd.to_numeric(
                result_df[weight_col], errors="coerce"
            )

        # Calculate CPM_per_mg
        # For rows with valid weight values
        valid_mask = (result_df[weight_col].notnull()) & (result_df[weight_col] > 0)

        if valid_mask.any():
            result_df.loc[valid_mask, "CPM_per_mg"] = (
                result_df.loc[valid_mask, cpm_col]
                / result_df.loc[valid_mask, weight_col]
            )

        # For rows with missing or zero weight values, use CPM as is
        invalid_mask = ~valid_mask

        if invalid_mask.any():
            logging.warning(
                f"Using CPM as CPM_per_mg for {invalid_mask.sum()} rows with missing or zero weight"
            )
            result_df.loc[invalid_mask, "CPM_per_mg"] = result_df.loc[
                invalid_mask, cpm_col
            ]

        # Complete progress
        if self._progress_callback:
            self._progress_callback("normalize_weight", 1.0, {})

        return result_df
