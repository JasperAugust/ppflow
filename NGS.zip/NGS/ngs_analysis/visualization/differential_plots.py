"""Differential analysis visualizations.

This module provides specialized plots for visualizing differential analysis results.
"""

from .plotters import BasePlotter
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import logging
import seaborn as sns
from typing import Dict, List, Optional, Tuple, Union, Any


class DifferentialPlotter(BasePlotter):
    """Creates visualizations for differential analysis."""

    def plot_differential_homing(
        self,
        df: pd.DataFrame,
        condition1: str,
        condition2: str,
        top_n: int = 20,
        fc_col: str = "log2FC_vs_input",
        organ: Optional[str] = None,
        peptide_col: str = "Peptide",
        label_points: bool = True,
        output_path: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Plot differential homing between conditions.

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with fold change values
        condition1: str
            First condition to compare
        condition2: str
            Second condition to compare
        top_n: int
            Number of top differential peptides to highlight
        fc_col: str
            Column containing fold change values
        organ: str
            Organ to filter for (if None, use all organs)
        peptide_col: str
            Column containing peptide sequences
        label_points: bool
            Whether to label the top differential peptides
        output_path: str
            Path to save figure

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Check if conditions exist
        conditions = df["condition"].unique()
        if condition1 not in conditions:
            raise ValueError(f"Condition '{condition1}' not found in data")
        if condition2 not in conditions:
            raise ValueError(f"Condition '{condition2}' not found in data")

        # Filter by organ if specified
        if organ is not None and "organ" in df.columns:
            if organ not in df["organ"].unique():
                raise ValueError(f"Organ '{organ}' not found in data")
            plot_df = df[df["organ"] == organ].copy()
        else:
            plot_df = df.copy()

        # Filter for the two conditions
        cond1_df = plot_df[plot_df["condition"] == condition1]
        cond2_df = plot_df[plot_df["condition"] == condition2]

        # Group by peptide and calculate mean fold change for each condition
        if "mouse_id" in plot_df.columns:
            # If we have mouse replicates, calculate mean per peptide per condition
            cond1_mean = cond1_df.groupby(peptide_col)[fc_col].mean()
            cond2_mean = cond2_df.groupby(peptide_col)[fc_col].mean()
        else:
            # If no replicates, use the values directly
            cond1_mean = cond1_df.set_index(peptide_col)[fc_col]
            cond2_mean = cond2_df.set_index(peptide_col)[fc_col]

        # Find peptides present in both conditions
        common_peptides = set(cond1_mean.index) & set(cond2_mean.index)

        if not common_peptides:
            logging.warning(
                f"No common peptides found between {condition1} and {condition2}"
            )
            return plt.subplots()  # Return empty figure

        # Create DataFrame for scatter plot
        scatter_df = pd.DataFrame(
            {
                peptide_col: list(common_peptides),
                f"{condition1}_{fc_col}": [cond1_mean[p] for p in common_peptides],
                f"{condition2}_{fc_col}": [cond2_mean[p] for p in common_peptides],
            }
        )

        # Calculate difference between conditions
        scatter_df["diff"] = (
            scatter_df[f"{condition1}_{fc_col}"] - scatter_df[f"{condition2}_{fc_col}"]
        )

        # Find top differential peptides (by absolute difference)
        scatter_df["abs_diff"] = np.abs(scatter_df["diff"])
        top_diff = scatter_df.nlargest(top_n, "abs_diff")

        # Create figure
        fig, ax = self.setup_figure()

        # Create scatter plot
        sns.scatterplot(
            x=f"{condition1}_{fc_col}",
            y=f"{condition2}_{fc_col}",
            data=scatter_df,
            alpha=0.7,
            color=self.config.get("scatter_color", "gray"),
            ax=ax,
        )

        # Highlight top differential peptides
        sns.scatterplot(
            x=f"{condition1}_{fc_col}",
            y=f"{condition2}_{fc_col}",
            data=top_diff,
            alpha=1.0,
            color=self.config.get("highlight_color", "red"),
            s=self.config.get("highlight_size", 100),
            ax=ax,
        )

        # Add diagonal line
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()

        # Find common limits for both axes
        min_val = min(xlim[0], ylim[0])
        max_val = max(xlim[1], ylim[1])

        ax.plot(
            [min_val, max_val],
            [min_val, max_val],
            linestyle="--",
            color="black",
            alpha=0.7,
        )

        # Set axis limits to be the same for both axes
        ax.set_xlim(min_val, max_val)
        ax.set_ylim(min_val, max_val)

        # Add reference lines at 0
        ax.axhline(0, color="gray", linestyle="-", alpha=0.3)
        ax.axvline(0, color="gray", linestyle="-", alpha=0.3)

        # Label points if requested
        if label_points:
            for i, row in top_diff.iterrows():
                peptide = row[peptide_col]
                x = row[f"{condition1}_{fc_col}"]
                y = row[f"{condition2}_{fc_col}"]

                # Abbreviate long peptides
                if len(peptide) > 12:
                    label = peptide[:5] + "..." + peptide[-5:]
                else:
                    label = peptide

                ax.annotate(
                    label,
                    xy=(x, y),
                    xytext=(5, 5),
                    textcoords="offset points",
                    fontsize=8,
                    alpha=0.8,
                )

        # Format axis
        title = f"Differential Enrichment: {condition1} vs {condition2}"
        if organ:
            title += f" in {organ}"

        xlabel = f"{condition1} {fc_col}"
        ylabel = f"{condition2} {fc_col}"

        self.format_axis(ax, title=title, xlabel=xlabel, ylabel=ylabel)

        # Save figure if requested
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_volcano_plot(
        self,
        df: pd.DataFrame,
        fc_col: str = "log2FC_diff",
        pval_col: str = "adjusted_p",
        peptide_col: str = "Peptide",
        fc_threshold: float = 1.0,
        pval_threshold: float = 0.05,
        top_n: int = 20,
        label_points: bool = True,
        output_path: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create a volcano plot for differential enrichment.

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with differential statistics
        fc_col: str
            Column containing fold change values (typically log2 scale)
        pval_col: str
            Column containing p-values
        peptide_col: str
            Column containing peptide sequences
        fc_threshold: float
            Fold change threshold for significance
        pval_threshold: float
            P-value threshold for significance
        top_n: int
            Number of top significant peptides to label
        label_points: bool
            Whether to label significant points
        output_path: str
            Path to save figure

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        if df.empty:
            logging.warning("Empty DataFrame provided for volcano plot")
            return plt.subplots()  # Return empty figure

        # Check required columns
        required_cols = {fc_col, pval_col, peptide_col}
        missing = required_cols - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        # Create a copy for plotting
        plot_df = df.copy()

        # Calculate -log10(p-value) for y-axis
        plot_df["-log10_pval"] = -np.log10(plot_df[pval_col])

        # Set non-finite values to a very large number (to avoid plotting issues)
        max_val = plot_df["-log10_pval"].replace([np.inf, -np.inf], np.nan).max()
        if not np.isnan(max_val):
            plot_df["-log10_pval"].replace([np.inf], max_val + 1, inplace=True)

        # Categorize points for coloring
        plot_df["category"] = "Not significant"

        # Points with significant p-value but not FC
        plot_df.loc[plot_df[pval_col] < pval_threshold, "category"] = (
            "P-value significant"
        )

        # Points with significant FC but not p-value
        plot_df.loc[(np.abs(plot_df[fc_col]) > fc_threshold), "category"] = (
            "Fold change significant"
        )

        # Points significant in both
        plot_df.loc[
            (plot_df[pval_col] < pval_threshold)
            & (np.abs(plot_df[fc_col]) > fc_threshold),
            "category",
        ] = "Both significant"

        # Create figure
        fig, ax = self.setup_figure()

        # Create scatter plot
        sns.scatterplot(
            x=fc_col,
            y="-log10_pval",
            hue="category",
            style="category",
            palette={
                "Not significant": "gray",
                "P-value significant": "blue",
                "Fold change significant": "green",
                "Both significant": "red",
            },
            data=plot_df,
            alpha=0.7,
            ax=ax,
        )

        # Add threshold lines
        ax.axhline(-np.log10(pval_threshold), color="gray", linestyle="--", alpha=0.7)
        ax.axvline(fc_threshold, color="gray", linestyle="--", alpha=0.7)
        ax.axvline(-fc_threshold, color="gray", linestyle="--", alpha=0.7)

        # Label top significant points
        if label_points:
            # Find top significant peptides
            significant = plot_df[plot_df["category"] == "Both significant"].copy()

            if not significant.empty:
                # Sort by combination of p-value and fold change
                significant["combined_score"] = significant["-log10_pval"] * np.abs(
                    significant[fc_col]
                )
                top_sig = significant.nlargest(top_n, "combined_score")

                for i, row in top_sig.iterrows():
                    peptide = row[peptide_col]
                    x = row[fc_col]
                    y = row["-log10_pval"]

                    # Abbreviate long peptides
                    if len(peptide) > 12:
                        label = peptide[:5] + "..." + peptide[-5:]
                    else:
                        label = peptide

                    ax.annotate(
                        label,
                        xy=(x, y),
                        xytext=(5, 5),
                        textcoords="offset points",
                        fontsize=8,
                        alpha=0.8,
                    )

        # Format axis
        title = "Volcano Plot"
        if "condition1" in df.columns and "condition2" in df.columns:
            cond1 = df["condition1"].iloc[0]
            cond2 = df["condition2"].iloc[0]
            title = f"Volcano Plot: {cond1} vs {cond2}"

        xlabel = f"Log2 Fold Change"
        ylabel = f"-log10(P-value)"

        self.format_axis(ax, title=title, xlabel=xlabel, ylabel=ylabel)

        # Save figure if requested
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_ma_plot(
        self,
        df: pd.DataFrame,
        fc_col: str = "log2FC_diff",
        pval_col: str = "adjusted_p",
        cpm_cols: Optional[Tuple[str, str]] = None,
        peptide_col: str = "Peptide",
        fc_threshold: float = 1.0,
        pval_threshold: float = 0.05,
        label_points: bool = True,
        top_n: int = 10,
        output_path: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create an MA plot (log ratio vs mean abundance).

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with differential statistics
        fc_col: str
            Column containing fold change values (typically log2 scale)
        pval_col: str
            Column containing p-values
        cpm_cols: tuple
            Tuple of column names for CPM values to calculate mean (condition1, condition2)
        peptide_col: str
            Column containing peptide sequences
        fc_threshold: float
            Fold change threshold for significance
        pval_threshold: float
            P-value threshold for significance
        label_points: bool
            Whether to label significant points
        top_n: int
            Number of top significant peptides to label
        output_path: str
            Path to save figure

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        if df.empty:
            logging.warning("Empty DataFrame provided for MA plot")
            return plt.subplots()  # Return empty figure

        # Check required columns
        required_cols = {fc_col, peptide_col}
        if pval_col:
            required_cols.add(pval_col)

        missing = required_cols - set(df.columns)
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        # Create a copy for plotting
        plot_df = df.copy()

        # Calculate mean abundance (A) if CPM columns provided
        if (
            cpm_cols
            and len(cpm_cols) == 2
            and all(col in df.columns for col in cpm_cols)
        ):
            # Calculate A = log2(mean(CPM1, CPM2))
            plot_df["mean_abundance"] = np.log2(
                (plot_df[cpm_cols[0]] + plot_df[cpm_cols[1]]) / 2
            )
        else:
            # If CPM columns not provided, try to estimate from condition mean FC values
            if "mean_log2FC_cond1" in df.columns and "mean_log2FC_cond2" in df.columns:
                # Estimate mean abundance from the average of fold changes
                plot_df["mean_abundance"] = (
                    plot_df["mean_log2FC_cond1"] + plot_df["mean_log2FC_cond2"]
                ) / 2
            else:
                # Create a dummy axis based on indices
                plot_df["mean_abundance"] = range(len(plot_df))
                logging.warning(
                    "No CPM or mean fold change columns found for MA plot; using index for x-axis"
                )

        # Categorize points for coloring
        if pval_col in plot_df.columns:
            plot_df["significant"] = (plot_df[pval_col] < pval_threshold) & (
                np.abs(plot_df[fc_col]) > fc_threshold
            )
        else:
            plot_df["significant"] = np.abs(plot_df[fc_col]) > fc_threshold

        # Create figure
        fig, ax = self.setup_figure()

        # Create scatter plot
        sns.scatterplot(
            x="mean_abundance",
            y=fc_col,
            hue="significant",
            palette={True: "red", False: "gray"},
            data=plot_df,
            alpha=0.7,
            ax=ax,
        )

        # Add threshold lines
        ax.axhline(0, color="black", linestyle="-", alpha=0.3)
        ax.axhline(fc_threshold, color="gray", linestyle="--", alpha=0.7)
        ax.axhline(-fc_threshold, color="gray", linestyle="--", alpha=0.7)

        # Label top significant points
        if label_points and "significant" in plot_df.columns:
            # Find top significant peptides
            significant = plot_df[plot_df["significant"]].copy()

            if not significant.empty:
                # Sort by absolute fold change
                significant["abs_fc"] = np.abs(significant[fc_col])
                top_sig = significant.nlargest(top_n, "abs_fc")

                for i, row in top_sig.iterrows():
                    peptide = row[peptide_col]
                    x = row["mean_abundance"]
                    y = row[fc_col]

                    # Abbreviate long peptides
                    if len(peptide) > 12:
                        label = peptide[:5] + "..." + peptide[-5:]
                    else:
                        label = peptide

                    ax.annotate(
                        label,
                        xy=(x, y),
                        xytext=(5, 5),
                        textcoords="offset points",
                        fontsize=8,
                        alpha=0.8,
                    )

        # Format axis
        title = "MA Plot"
        if "condition1" in df.columns and "condition2" in df.columns:
            cond1 = df["condition1"].iloc[0]
            cond2 = df["condition2"].iloc[0]
            title = f"MA Plot: {cond1} vs {cond2}"

        xlabel = "Mean Log2 Abundance"
        ylabel = "Log2 Fold Change"

        self.format_axis(ax, title=title, xlabel=xlabel, ylabel=ylabel)

        # Save figure if requested
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax
