"""Report generation module.

This module provides functionality for generating publication-quality reports
from phage display analysis results.
"""

import os
import pandas as pd
import logging
from typing import Dict, List, Optional, Tuple, Union, Any

from .plotters import BasePlotter
from .enrichment_plots import EnrichmentPlotter
from .differential_plots import DifferentialPlotter


class Reporter:
    """Generates comprehensive reports from analysis results."""

    def __init__(self, config=None):
        self.config = config or {}

        # Set up default configuration values
        self.output_dir = self.config.get("output_dir", "results")
        os.makedirs(self.output_dir, exist_ok=True)

        # Initialize plotters
        self.base_plotter = BasePlotter(config)
        self.enrichment_plotter = EnrichmentPlotter(config)
        self.differential_plotter = DifferentialPlotter(config)

    def generate_full_report(self, results: Dict[str, Any]) -> Dict[str, List[str]]:
        """Generate a complete report for all analysis results.

        Parameters:
        -----------
        results: dict
            Results dictionary from AnalysisWorkflow

        Returns:
        --------
        dict
            Dictionary mapping report sections to lists of generated files
        """
        if results.get("status") != "completed":
            logging.warning(
                f"Cannot generate report for incomplete analysis: {results.get('status')}"
            )
            return {"status": results.get("status")}

        # Create output directory
        output_dir = results.get("output_dir", self.output_dir)
        os.makedirs(output_dir, exist_ok=True)

        report_files = {}

        # Generate enrichment plots
        enrichment_files = self.generate_enrichment_plots(
            results.get("merged_data"),
            results.get("stats_df"),
            results.get("enriched_df"),
            output_dir=output_dir,
        )
        report_files["enrichment"] = enrichment_files

        # Generate differential plots
        if results.get("condition_comparisons"):
            differential_files = self.generate_differential_plots(
                results.get("merged_data"),
                results.get("condition_comparisons"),
                output_dir=output_dir,
            )
            report_files["differential"] = differential_files

        # Generate organ distribution plots if organ data is available
        if (
            results.get("merged_data") is not None
            and "organ" in results.get("merged_data").columns
        ):
            organ_files = self.generate_organ_distribution_plots(
                results.get("merged_data"),
                results.get("enriched_df"),
                output_dir=output_dir,
            )
            report_files["organ_distribution"] = organ_files

        # Save summary tables
        summary_files = self.save_summary_tables(results, output_dir=output_dir)
        report_files["summary_tables"] = summary_files

        return report_files

    def generate_enrichment_plots(
        self,
        merged_data: pd.DataFrame,
        stats_df: pd.DataFrame,
        enriched_df: pd.DataFrame,
        output_dir: str = None,
    ) -> List[str]:
        """Generate plots for enrichment analysis.

        Parameters:
        -----------
        merged_data: pd.DataFrame
            Merged data with fold change values
        stats_df: pd.DataFrame
            Statistics DataFrame
        enriched_df: pd.DataFrame
            DataFrame with enriched peptides
        output_dir: str
            Directory to save plots

        Returns:
        --------
        list
            List of generated file paths
        """
        if output_dir is None:
            output_dir = self.output_dir

        os.makedirs(output_dir, exist_ok=True)
        generated_files = []

        if merged_data is None or merged_data.empty:
            logging.warning("No merged data available for enrichment plots")
            return generated_files

        try:
            # Generate fold over control plots for each condition and organ
            if "condition" in merged_data.columns:
                conditions = merged_data["condition"].unique()

                for condition in conditions:
                    # Check if organ column exists
                    if "organ" in merged_data.columns:
                        organs = merged_data[merged_data["condition"] == condition][
                            "organ"
                        ].unique()

                        for organ in organs:
                            # Skip if organ is NaN
                            if pd.isna(organ):
                                continue

                            # Fold over control with error bars
                            try:
                                output_path = os.path.join(
                                    output_dir, f"{condition}_{organ}_fold_over_control"
                                )
                                fig, ax = (
                                    self.enrichment_plotter.plot_fold_over_control_with_error_bars(
                                        merged_data,
                                        condition=condition,
                                        organ=organ,
                                        top_n=10,
                                        output_path=output_path,
                                    )
                                )
                                generated_files.extend(
                                    self.enrichment_plotter.save_figure(
                                        fig, output_path
                                    )
                                )
                            except Exception as e:
                                logging.warning(
                                    f"Error generating fold over control plot for {condition}, {organ}: {str(e)}"
                                )

                            # Fold over control grouped by mouse
                            try:
                                output_path = os.path.join(
                                    output_dir, f"{condition}_{organ}_fold_by_mouse"
                                )
                                fig, ax = (
                                    self.enrichment_plotter.plot_fold_over_control_grouped_by_mouse(
                                        merged_data,
                                        condition=condition,
                                        organ=organ,
                                        top_n=10,
                                        output_path=output_path,
                                    )
                                )
                                generated_files.extend(
                                    self.enrichment_plotter.save_figure(
                                        fig, output_path
                                    )
                                )
                            except Exception as e:
                                logging.warning(
                                    f"Error generating fold by mouse plot for {condition}, {organ}: {str(e)}"
                                )
                    else:
                        # No organ column, plot by condition only
                        try:
                            output_path = os.path.join(
                                output_dir, f"{condition}_fold_over_control"
                            )
                            fig, ax = (
                                self.enrichment_plotter.plot_fold_over_control_with_error_bars(
                                    merged_data,
                                    condition=condition,
                                    organ=None,
                                    top_n=10,
                                    output_path=output_path,
                                )
                            )
                            generated_files.extend(
                                self.enrichment_plotter.save_figure(fig, output_path)
                            )
                        except Exception as e:
                            logging.warning(
                                f"Error generating fold over control plot for {condition}: {str(e)}"
                            )

            # Generate heatmap of top enriched peptides
            if stats_df is not None and not stats_df.empty:
                try:
                    output_path = os.path.join(output_dir, "enrichment_heatmap")
                    fig, ax = self.enrichment_plotter.plot_enrichment_heatmap(
                        stats_df,
                        fc_col="mean_log2FC",
                        top_n=20,
                        output_path=output_path,
                    )
                    generated_files.extend(
                        self.enrichment_plotter.save_figure(fig, output_path)
                    )
                except Exception as e:
                    logging.warning(f"Error generating enrichment heatmap: {str(e)}")
        except Exception as e:
            logging.error(f"Error generating enrichment plots: {str(e)}")

        return generated_files

    def generate_differential_plots(
        self,
        merged_data: pd.DataFrame,
        condition_comparisons: Dict[str, pd.DataFrame],
        output_dir: str = None,
    ) -> List[str]:
        """Generate plots for differential analysis.

        Parameters:
        -----------
        merged_data: pd.DataFrame
            Merged data with fold change values
        condition_comparisons: dict
            Dictionary of condition comparison DataFrames
        output_dir: str
            Directory to save plots

        Returns:
        --------
        list
            List of generated file paths
        """
        if output_dir is None:
            output_dir = self.output_dir

        os.makedirs(output_dir, exist_ok=True)
        generated_files = []

        if merged_data is None or merged_data.empty:
            logging.warning("No merged data available for differential plots")
            return generated_files

        if not condition_comparisons:
            logging.warning("No condition comparisons available for differential plots")
            return generated_files

        try:
            # Process each condition comparison
            for comparison_key, comparison_df in condition_comparisons.items():
                if comparison_df.empty:
                    continue

                conditions = comparison_key.split("_vs_")
                if len(conditions) != 2:
                    continue

                condition1, condition2 = conditions

                # Check if organ column exists
                if "organ" in merged_data.columns:
                    organs = merged_data["organ"].unique()

                    for organ in organs:
                        # Skip if organ is NaN
                        if pd.isna(organ):
                            continue

                        # Differential homing plot
                        try:
                            output_path = os.path.join(
                                output_dir, f"{comparison_key}_{organ}_differential"
                            )
                            fig, ax = (
                                self.differential_plotter.plot_differential_homing(
                                    merged_data,
                                    condition1=condition1,
                                    condition2=condition2,
                                    organ=organ,
                                    top_n=20,
                                    output_path=output_path,
                                )
                            )
                            generated_files.extend(
                                self.differential_plotter.save_figure(fig, output_path)
                            )
                        except Exception as e:
                            logging.warning(
                                f"Error generating differential plot for {comparison_key}, {organ}: {str(e)}"
                            )
                else:
                    # No organ column, plot by condition only
                    try:
                        output_path = os.path.join(
                            output_dir, f"{comparison_key}_differential"
                        )
                        fig, ax = self.differential_plotter.plot_differential_homing(
                            merged_data,
                            condition1=condition1,
                            condition2=condition2,
                            organ=None,
                            top_n=20,
                            output_path=output_path,
                        )
                        generated_files.extend(
                            self.differential_plotter.save_figure(fig, output_path)
                        )
                    except Exception as e:
                        logging.warning(
                            f"Error generating differential plot for {comparison_key}: {str(e)}"
                        )

                # Volcano plot
                if (
                    "adjusted_p" in comparison_df.columns
                    and "log2FC_diff" in comparison_df.columns
                ):
                    try:
                        output_path = os.path.join(
                            output_dir, f"{comparison_key}_volcano"
                        )
                        fig, ax = self.differential_plotter.plot_volcano_plot(
                            comparison_df,
                            fc_col="log2FC_diff",
                            pval_col="adjusted_p",
                            top_n=20,
                            output_path=output_path,
                        )
                        generated_files.extend(
                            self.differential_plotter.save_figure(fig, output_path)
                        )
                    except Exception as e:
                        logging.warning(
                            f"Error generating volcano plot for {comparison_key}: {str(e)}"
                        )

                # MA plot
                if "log2FC_diff" in comparison_df.columns:
                    try:
                        output_path = os.path.join(
                            output_dir, f"{comparison_key}_ma_plot"
                        )
                        fig, ax = self.differential_plotter.plot_ma_plot(
                            comparison_df,
                            fc_col="log2FC_diff",
                            top_n=10,
                            output_path=output_path,
                        )
                        generated_files.extend(
                            self.differential_plotter.save_figure(fig, output_path)
                        )
                    except Exception as e:
                        logging.warning(
                            f"Error generating MA plot for {comparison_key}: {str(e)}"
                        )
        except Exception as e:
            logging.error(f"Error generating differential plots: {str(e)}")

        return generated_files

    def generate_organ_distribution_plots(
        self,
        merged_data: pd.DataFrame,
        enriched_df: pd.DataFrame = None,
        top_n: int = 10,
        output_dir: str = None,
    ) -> List[str]:
        """Generate organ distribution boxplots.

        Creates multi-panel figures showing the distribution of top peptides
        across different organs, similar to scientific publications.

        Parameters:
        -----------
        merged_data: pd.DataFrame
            Merged data with fold change values
        enriched_df: pd.DataFrame
            DataFrame with enriched peptides to prioritize
        top_n: int
            Number of top peptides to include
        output_dir: str
            Directory to save plots

        Returns:
        --------
        List[str]: List of generated file paths
        """
        if merged_data is None or merged_data.empty:
            logging.warning(
                "Cannot generate organ distribution plots: No data provided"
            )
            return []

        if "organ" not in merged_data.columns:
            logging.warning(
                "Cannot generate organ distribution plots: No organ information in data"
            )
            return []

        # Set output directory
        if output_dir is None:
            output_dir = self.output_dir

        # Create output directory
        os.makedirs(output_dir, exist_ok=True)

        generated_files = []

        # Get the top peptides to plot
        if enriched_df is not None and not enriched_df.empty:
            # Use top enriched peptides based on fold change
            top_peptides = (
                enriched_df.sort_values("fold_over_control", ascending=False)["Peptide"]
                .head(top_n)
                .tolist()
            )
        else:
            # Use the peptides with highest median fold change
            median_fc = merged_data.groupby("Peptide")["fold_over_control"].median()
            top_peptides = (
                median_fc.sort_values(ascending=False).head(top_n).index.tolist()
            )

        # Get conditions
        conditions = (
            merged_data["condition"].unique()
            if "condition" in merged_data.columns
            else [None]
        )

        # Create plots for each condition
        for condition in conditions:
            condition_str = f"_{condition}" if condition else ""

            # Generate multi-panel plots with top peptides
            if top_peptides:
                # Create plots for top peptides
                output_path = os.path.join(
                    output_dir, f"top_peptides_organ_distribution{condition_str}"
                )

                try:
                    # Create plot for top peptides
                    fig, axs = self.enrichment_plotter.plot_peptide_organ_comparison(
                        df=merged_data,
                        peptides=top_peptides[:4],  # Use top 4 for a clean 2x2 grid
                        condition=condition,
                        output_path=output_path,
                    )

                    generated_files.extend([f"{output_path}.png", f"{output_path}.pdf"])

                    # Create separate plots if there are more than 4 top peptides
                    if len(top_peptides) > 4:
                        for start_idx in range(4, len(top_peptides), 4):
                            next_peptides = top_peptides[start_idx : start_idx + 4]
                            if not next_peptides:
                                break

                            output_path = os.path.join(
                                output_dir,
                                f"top_peptides_organ_distribution{condition_str}_{start_idx // 4 + 1}",
                            )

                            fig, axs = (
                                self.enrichment_plotter.plot_peptide_organ_comparison(
                                    df=merged_data,
                                    peptides=next_peptides,
                                    condition=condition,
                                    output_path=output_path,
                                )
                            )

                            generated_files.extend(
                                [f"{output_path}.png", f"{output_path}.pdf"]
                            )
                except Exception as e:
                    logging.warning(
                        f"Error generating organ distribution plots: {str(e)}"
                    )

        return generated_files

    def save_summary_tables(
        self, results: Dict[str, Any], output_dir: str = None
    ) -> List[str]:
        """Save summary tables to CSV files.

        Parameters:
        -----------
        results: dict
            Results dictionary from AnalysisWorkflow
        output_dir: str
            Directory to save tables

        Returns:
        --------
        list
            List of generated file paths
        """
        if output_dir is None:
            output_dir = self.output_dir

        os.makedirs(output_dir, exist_ok=True)
        generated_files = []

        try:
            # Save merged data
            if results.get("merged_data") is not None:
                merged_file = os.path.join(output_dir, "merged_data.csv")
                results["merged_data"].to_csv(merged_file, index=False)
                generated_files.append(merged_file)

            # Save statistics results
            if results.get("stats_df") is not None:
                stats_file = os.path.join(output_dir, "statistics.csv")
                results["stats_df"].to_csv(stats_file, index=False)
                generated_files.append(stats_file)

            # Save enriched peptides
            if results.get("enriched_df") is not None:
                enriched_file = os.path.join(output_dir, "enriched_peptides.csv")
                results["enriched_df"].to_csv(enriched_file, index=False)
                generated_files.append(enriched_file)

            # Save depleted peptides
            if results.get("depleted_df") is not None:
                depleted_file = os.path.join(output_dir, "depleted_peptides.csv")
                results["depleted_df"].to_csv(depleted_file, index=False)
                generated_files.append(depleted_file)

            # Save condition comparisons
            for comparison_key, comparison_df in results.get(
                "condition_comparisons", {}
            ).items():
                if comparison_df is not None:
                    comparison_file = os.path.join(
                        output_dir, f"{comparison_key}_comparison.csv"
                    )
                    comparison_df.to_csv(comparison_file, index=False)
                    generated_files.append(comparison_file)
        except Exception as e:
            logging.error(f"Error saving summary tables: {str(e)}")

        return generated_files
