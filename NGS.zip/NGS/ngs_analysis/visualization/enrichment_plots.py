"""Enrichment-specific visualizations.

This module provides specialized plots for visualizing enrichment data from phage display experiments.
"""

from .plotters import BasePlotter
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple, Union, Any
import seaborn as sns


class EnrichmentPlotter(BasePlotter):
    """Creates visualizations for enrichment analysis."""

    def plot_fold_over_control_with_error_bars(
        self,
        df: pd.DataFrame,
        condition: str,
        organ: str,
        fc_col: str = "fold_over_control",
        top_n: int = 10,
        ci_type: str = "sd",  # 'sd' (std dev) or 'se' (std error) or '95' (95% CI)
        output_path: Optional[str] = None,
        peptide_col: str = "Peptide",
        log_scale: bool = True,
        horizontal: bool = True,
        control_peptide: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Plot fold change over control with error bars.

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with fold change values
        condition: str
            Condition to plot
        organ: str
            Organ to plot
        fc_col: str
            Column containing fold change values
        top_n: int
            Number of top peptides to plot
        ci_type: str
            Type of confidence interval ('sd', 'se', or '95')
        output_path: str
            Path to save figure (without extension)
        peptide_col: str
            Column containing peptide sequences
        log_scale: bool
            Whether to use log scale for fold change
        horizontal: bool
            Whether to plot horizontal bars
        control_peptide: str
            Control peptide to highlight

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Filter data for the specified condition and organ
        if condition not in df["condition"].unique():
            raise ValueError(f"Condition '{condition}' not found in data")

        if "organ" in df.columns and organ not in df["organ"].unique():
            raise ValueError(f"Organ '{organ}' not found in data")

        # Filter data
        if "organ" in df.columns:
            plot_df = df[(df["condition"] == condition) & (df["organ"] == organ)].copy()
        else:
            plot_df = df[df["condition"] == condition].copy()

        if plot_df.empty:
            logging.warning(f"No data found for condition={condition}, organ={organ}")
            return plt.subplots()  # Return empty figure

        # Group by peptide and calculate statistics
        grouped = (
            plot_df.groupby(peptide_col)
            .agg({fc_col: ["mean", "std", "sem", "count"]})
            .reset_index()
        )

        # Flatten multi-level columns
        grouped.columns = [
            "_".join(col).strip("_") if col[1] else col[0]
            for col in grouped.columns.values
        ]

        # Calculate confidence intervals
        if ci_type == "sd":
            # Standard deviation
            grouped["ci_low"] = grouped[f"{fc_col}_mean"] - grouped[f"{fc_col}_std"]
            grouped["ci_high"] = grouped[f"{fc_col}_mean"] + grouped[f"{fc_col}_std"]
            ci_label = "Standard Deviation"
        elif ci_type == "se":
            # Standard error of the mean
            grouped["ci_low"] = grouped[f"{fc_col}_mean"] - grouped[f"{fc_col}_sem"]
            grouped["ci_high"] = grouped[f"{fc_col}_mean"] + grouped[f"{fc_col}_sem"]
            ci_label = "Standard Error"
        elif ci_type == "95":
            # 95% confidence interval (using t-distribution)
            grouped["ci_low"] = grouped.apply(
                lambda row: row[f"{fc_col}_mean"]
                - row[f"{fc_col}_sem"]
                * (
                    1.96
                    if row[f"{fc_col}_count"] > 30
                    else np.abs(
                        np.round(
                            np.quantile(
                                np.random.standard_t(row[f"{fc_col}_count"] - 1), 0.025
                            ),
                            4,
                        )
                    )
                ),
                axis=1,
            )
            grouped["ci_high"] = grouped.apply(
                lambda row: row[f"{fc_col}_mean"]
                + row[f"{fc_col}_sem"]
                * (
                    1.96
                    if row[f"{fc_col}_count"] > 30
                    else np.abs(
                        np.round(
                            np.quantile(
                                np.random.standard_t(row[f"{fc_col}_count"] - 1), 0.025
                            ),
                            4,
                        )
                    )
                ),
                axis=1,
            )
            ci_label = "95% Confidence Interval"
        else:
            raise ValueError(f"Unknown CI type: {ci_type}")

        # Ensure positive values for log scale if needed
        if log_scale:
            # Find minimum positive value for pseudocount
            min_positive = np.min(
                grouped[grouped[f"{fc_col}_mean"] > 0][f"{fc_col}_mean"]
            )
            pseudocount = min(min_positive / 10, 0.1)  # Small fraction of minimum value

            # Apply pseudocount
            grouped[f"{fc_col}_mean"] = grouped[f"{fc_col}_mean"].apply(
                lambda x: max(x, pseudocount)
            )
            grouped["ci_low"] = grouped["ci_low"].apply(lambda x: max(x, pseudocount))

        # Sort by mean fold change (descending)
        grouped = grouped.sort_values(f"{fc_col}_mean", ascending=False)

        # Take top N peptides
        if top_n > 0 and len(grouped) > top_n:
            # If control peptide specified, keep it in addition to top N
            if control_peptide and control_peptide in grouped[peptide_col].values:
                top_peptides = grouped.head(top_n)[peptide_col].tolist()
                if control_peptide not in top_peptides:
                    control_row = grouped[grouped[peptide_col] == control_peptide]
                    top_grouped = pd.concat([grouped.head(top_n - 1), control_row])
                else:
                    top_grouped = grouped.head(top_n)
            else:
                top_grouped = grouped.head(top_n)
        else:
            top_grouped = grouped

        # Sort so highest fold change is at the top for horizontal plot
        if horizontal:
            top_grouped = top_grouped.sort_values(f"{fc_col}_mean", ascending=True)

        # Create figure
        figsize = self.figure_size
        if horizontal and len(top_grouped) > 5:
            # Adjust height based on number of peptides for horizontal plot
            height = max(8, len(top_grouped) * 0.5)
            figsize = (self.figure_size[0], height)

        fig, ax = self.setup_figure(figsize)

        # Create plot
        if horizontal:
            # Horizontal bar plot
            ax.barh(
                top_grouped[peptide_col],
                top_grouped[f"{fc_col}_mean"],
                xerr=None,  # We'll add error bars manually
                color=self.config.get("bar_color", "royalblue"),
                alpha=0.7,
                capsize=5,
            )

            # Add error bars manually
            for i, row in enumerate(top_grouped.itertuples()):
                peptide = getattr(row, peptide_col)
                mean = getattr(row, f"{fc_col}_mean")
                ci_low = row.ci_low
                ci_high = row.ci_high

                # Add custom error bar (high - mean and mean - low)
                ax.errorbar(
                    x=mean,
                    y=i,  # Use index for y position
                    xerr=[[mean - ci_low], [ci_high - mean]],
                    fmt="none",
                    ecolor="black",
                    capsize=5,
                )

            # Set log scale if requested
            if log_scale:
                ax.set_xscale("log")

            # Add reference line at 1 (no change)
            ax.axvline(1, color="black", linestyle="--", alpha=0.5)

            # Format axis
            title = f"Fold Change over Control ({condition}, {organ})"
            xlabel = f"Fold Change over Control ({ci_label})"
            ylabel = "Peptide"

        else:
            # Vertical bar plot
            ax.bar(
                top_grouped[peptide_col],
                top_grouped[f"{fc_col}_mean"],
                yerr=None,  # We'll add error bars manually
                color=self.config.get("bar_color", "royalblue"),
                alpha=0.7,
                capsize=5,
            )

            # Add error bars manually
            for i, row in enumerate(top_grouped.itertuples()):
                peptide = getattr(row, peptide_col)
                mean = getattr(row, f"{fc_col}_mean")
                ci_low = row.ci_low
                ci_high = row.ci_high

                # Add custom error bar (high - mean and mean - low)
                ax.errorbar(
                    x=i,  # Use index for x position
                    y=mean,
                    yerr=[[mean - ci_low], [ci_high - mean]],
                    fmt="none",
                    ecolor="black",
                    capsize=5,
                )

            # Set log scale if requested
            if log_scale:
                ax.set_yscale("log")

            # Add reference line at 1 (no change)
            ax.axhline(1, color="black", linestyle="--", alpha=0.5)

            # Format axis
            title = f"Fold Change over Control ({condition}, {organ})"
            xlabel = "Peptide"
            ylabel = f"Fold Change over Control ({ci_label})"

        # Format axis
        self.format_axis(ax, title=title, xlabel=xlabel, ylabel=ylabel)

        # Save figure if requested
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_fold_over_control_grouped_by_mouse(
        self,
        df: pd.DataFrame,
        condition: str,
        organ: str,
        fc_col: str = "fold_over_control",
        top_n: int = 10,
        output_path: Optional[str] = None,
        peptide_col: str = "Peptide",
        mouse_col: str = "mouse_id",
        log_scale: bool = True,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Plot fold change over control grouped by mouse.

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with fold change values
        condition: str
            Condition to plot
        organ: str
            Organ to plot
        fc_col: str
            Column containing fold change values
        top_n: int
            Number of top peptides to plot
        output_path: str
            Path to save figure (without extension)
        peptide_col: str
            Column containing peptide sequences
        mouse_col: str
            Column containing mouse IDs
        log_scale: bool
            Whether to use log scale for fold change

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Filter data for the specified condition and organ
        if condition not in df["condition"].unique():
            raise ValueError(f"Condition '{condition}' not found in data")

        if "organ" in df.columns and organ not in df["organ"].unique():
            raise ValueError(f"Organ '{organ}' not found in data")

        # Filter data
        if "organ" in df.columns:
            plot_df = df[(df["condition"] == condition) & (df["organ"] == organ)].copy()
        else:
            plot_df = df[df["condition"] == condition].copy()

        if plot_df.empty:
            logging.warning(f"No data found for condition={condition}, organ={organ}")
            return plt.subplots()  # Return empty figure

        # Make sure we have a mouse_id column
        if mouse_col not in plot_df.columns:
            raise ValueError(f"Mouse column '{mouse_col}' not found in data")

        # Calculate mean fold change across all mice
        mean_fc = plot_df.groupby(peptide_col)[fc_col].mean().reset_index()

        # Sort by mean fold change (descending)
        mean_fc = mean_fc.sort_values(fc_col, ascending=False)

        # Select top N peptides
        if top_n > 0 and len(mean_fc) > top_n:
            top_peptides = mean_fc.head(top_n)[peptide_col].tolist()
        else:
            top_peptides = mean_fc[peptide_col].tolist()

        # Filter original data to include only top peptides
        plot_df_filtered = plot_df[plot_df[peptide_col].isin(top_peptides)]

        # Ensure peptides are in the right order (highest mean FC first)
        plot_df_filtered = plot_df_filtered.merge(
            mean_fc[[peptide_col, fc_col]].rename(columns={fc_col: "mean_fc"}),
            on=peptide_col,
        )

        # Create figure
        fig, ax = self.setup_figure()

        # Create box plot or violin plot
        use_violin = self.config.get("use_violin", False)

        if use_violin:
            # Violin plot
            sns_plot = sns.violinplot(
                x=peptide_col,
                y=fc_col,
                data=plot_df_filtered,
                palette=self.config.get("palette", "deep"),
                inner="quartile",  # Show quartiles inside violin
                ax=ax,
            )
        else:
            # Box plot with points for individual mice
            sns_plot = sns.boxplot(
                x=peptide_col,
                y=fc_col,
                data=plot_df_filtered,
                palette=self.config.get("palette", "deep"),
                ax=ax,
            )

            # Add individual points
            sns.stripplot(
                x=peptide_col,
                y=fc_col,
                data=plot_df_filtered,
                color="black",
                size=4,
                jitter=True,
                alpha=0.7,
                ax=ax,
            )

        # Set log scale if requested
        if log_scale and fc_col == "fold_over_control":
            ax.set_yscale("log")

        # Add reference line at 1 (no change)
        ax.axhline(1, color="black", linestyle="--", alpha=0.5)

        # Format axis
        title = f"Fold Change over Control by Mouse ({condition}, {organ})"
        xlabel = "Peptide"
        ylabel = "Fold Change over Control"

        self.format_axis(ax, title=title, xlabel=xlabel, ylabel=ylabel)

        # Save figure if requested
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_enrichment_heatmap(
        self,
        df: pd.DataFrame,
        fc_col: str = "log2FC_vs_input",
        peptide_col: str = "Peptide",
        condition_col: str = "condition",
        organ_col: Optional[str] = "organ",
        top_n: int = 20,
        center: float = 0,
        cmap: str = "RdBu_r",
        output_path: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Plot heatmap of enrichment fold changes.

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with fold change values
        fc_col: str
            Column containing fold change values
        peptide_col: str
            Column containing peptide sequences
        condition_col: str
            Column containing condition labels
        organ_col: str
            Column containing organ labels (if None, not used for grouping)
        top_n: int
            Number of top peptides to include
        center: float
            Center value for colormap
        cmap: str
            Colormap name
        output_path: str
            Path to save figure

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Group by peptide and calculate mean fold change
        if organ_col is not None and organ_col in df.columns:
            # Group by peptide, condition, and organ
            grouped = (
                df.groupby([peptide_col, condition_col, organ_col])[fc_col]
                .mean()
                .reset_index()
            )

            # Find top peptides across all conditions and organs
            mean_fc = df.groupby(peptide_col)[fc_col].mean().reset_index()
            mean_fc = mean_fc.sort_values(fc_col, ascending=False)

            if top_n > 0 and len(mean_fc) > top_n:
                top_peptides = mean_fc.head(top_n)[peptide_col].tolist()
            else:
                top_peptides = mean_fc[peptide_col].tolist()

            # Filter to include only top peptides
            grouped = grouped[grouped[peptide_col].isin(top_peptides)]

            # Create pivot table for heatmap
            pivot_data = pd.pivot_table(
                grouped,
                values=fc_col,
                index=peptide_col,
                columns=[condition_col, organ_col],
            )

        else:
            # Group by peptide and condition only
            grouped = (
                df.groupby([peptide_col, condition_col])[fc_col].mean().reset_index()
            )

            # Find top peptides across all conditions
            mean_fc = df.groupby(peptide_col)[fc_col].mean().reset_index()
            mean_fc = mean_fc.sort_values(fc_col, ascending=False)

            if top_n > 0 and len(mean_fc) > top_n:
                top_peptides = mean_fc.head(top_n)[peptide_col].tolist()
            else:
                top_peptides = mean_fc[peptide_col].tolist()

            # Filter to include only top peptides
            grouped = grouped[grouped[peptide_col].isin(top_peptides)]

            # Create pivot table for heatmap
            pivot_data = pd.pivot_table(
                grouped, values=fc_col, index=peptide_col, columns=condition_col
            )

        # Create figure
        figsize = self.figure_size
        # Adjust height based on number of peptides
        height = max(8, len(top_peptides) * 0.4)
        figsize = (self.figure_size[0], height)

        fig, ax = self.setup_figure(figsize)

        # Determine color scale limits
        vmin = self.config.get("vmin", None)
        vmax = self.config.get("vmax", None)

        if vmin is None or vmax is None:
            # Set symmetrical limits based on data
            abs_max = max(abs(pivot_data.min().min()), abs(pivot_data.max().max()))
            if vmin is None:
                vmin = -abs_max
            if vmax is None:
                vmax = abs_max

        # Create heatmap
        sns.heatmap(
            pivot_data,
            ax=ax,
            cmap=cmap,
            center=center,
            vmin=vmin,
            vmax=vmax,
            annot=True,
            fmt=".1f",
            cbar_kws={"label": "Log2 Fold Change"},
        )

        # Format axis
        title = f"Enrichment Heatmap (Top {len(top_peptides)} Peptides)"

        self.format_axis(ax, title=title)

        # Save figure if requested
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_organ_distribution_boxplots(
        self,
        df: pd.DataFrame,
        peptides: List[str],
        fc_col: str = "fold_over_control",
        organ_col: str = "organ",
        peptide_col: str = "Peptide",
        control_peptide: Optional[str] = None,
        organ_order: Optional[List[str]] = None,
        output_path: Optional[str] = None,
        show_points: bool = True,
        ncols: int = 2,
        figsize: Optional[Tuple[float, float]] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create multi-panel boxplots showing peptide distribution across organs.

        Inspired by organ-specific phage display visualization from scientific literature,
        this creates a multi-panel figure with one panel per peptide, showing boxplots
        of fold change values across different organs.

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with fold change values
        peptides: List[str]
            List of peptides to plot (each will get its own panel)
        fc_col: str
            Column containing fold change values
        organ_col: str
            Column containing organ information
        peptide_col: str
            Column containing peptide sequences
        control_peptide: str
            Control peptide to highlight
        organ_order: List[str]
            Order of organs to display (if None, will use alphabetical)
        output_path: str
            Path to save figure (without extension)
        show_points: bool
            Whether to show individual data points
        ncols: int
            Number of columns in the panel grid
        figsize: Tuple[float, float]
            Custom figure size (width, height)

        Returns:
        --------
        fig, axs: matplotlib figure and axes objects
        """
        # Check if required columns exist
        if peptide_col not in df.columns:
            raise ValueError(f"Peptide column '{peptide_col}' not found in data")
        if fc_col not in df.columns:
            raise ValueError(f"Fold change column '{fc_col}' not found in data")
        if organ_col not in df.columns:
            raise ValueError(f"Organ column '{organ_col}' not found in data")

        # Filter data to include only the requested peptides
        plot_df = df[df[peptide_col].isin(peptides)].copy()

        if plot_df.empty:
            logging.warning(f"No data found for specified peptides")
            return plt.subplots()  # Return empty figure

        # Determine organ order
        if organ_order is None:
            organ_order = sorted(plot_df[organ_col].unique())

        # Calculate the grid layout
        n_peptides = len(peptides)
        nrows = (n_peptides + ncols - 1) // ncols  # Ceiling division

        # Create figure
        if figsize is None:
            figsize = (5 * ncols, 4 * nrows)

        fig, axs = plt.subplots(nrows, ncols, figsize=figsize, squeeze=False)
        axs = axs.flatten()

        # Set up color palette
        palette = self.get_palette(n_colors=len(organ_order))

        # Determine the maximum y-value for consistent scaling
        y_max = plot_df[fc_col].max() * 1.1  # Add 10% padding

        # Create one panel per peptide
        for i, peptide in enumerate(peptides):
            if i >= len(axs):
                break

            ax = axs[i]
            peptide_data = plot_df[plot_df[peptide_col] == peptide]

            if peptide_data.empty:
                ax.text(
                    0.5,
                    0.5,
                    f"No data for {peptide}",
                    ha="center",
                    va="center",
                    transform=ax.transAxes,
                )
                continue

            # Create boxplot with seaborn
            sns.boxplot(
                data=peptide_data,
                x=organ_col,
                y=fc_col,
                order=organ_order,
                palette=palette,
                ax=ax,
                linewidth=1.5,
                fliersize=3,
                width=0.6,
            )

            # Optionally add individual data points
            if show_points:
                sns.stripplot(
                    data=peptide_data,
                    x=organ_col,
                    y=fc_col,
                    order=organ_order,
                    color="black",
                    size=4,
                    alpha=0.7,
                    jitter=True,
                    ax=ax,
                )

            # Set title and labels
            ax.set_title(f"{peptide}", fontsize=14, pad=10)
            ax.set_xlabel("")

            if i % ncols == 0:  # Only show y-label on left edge
                ax.set_ylabel(f"Fold Change", fontsize=12)
            else:
                ax.set_ylabel("")

            # Set consistent y-axis limits
            ax.set_ylim(0, y_max)

            # Add horizontal grid lines
            ax.grid(axis="y", linestyle="--", alpha=0.7)

            # Customize tick labels
            ax.tick_params(axis="x", labelsize=10)
            ax.tick_params(axis="y", labelsize=10)

        # Hide empty subplots
        for i in range(n_peptides, len(axs)):
            axs[i].set_visible(False)

        # Add a letter label to each panel (A, B, C, D, etc.)
        for i, ax in enumerate(axs[:n_peptides]):
            panel_letter = chr(65 + i)  # 65 is ASCII for 'A'
            ax.text(
                -0.1,
                1.05,
                panel_letter,
                transform=ax.transAxes,
                fontsize=16,
                fontweight="bold",
                va="top",
            )

        # Adjust layout
        plt.tight_layout()

        # Save figure if output path is provided
        if output_path:
            self.save_figure(fig, output_path)

        return fig, axs

    def plot_peptide_organ_comparison(
        self,
        df: pd.DataFrame,
        peptides: List[str],
        organs: Optional[List[str]] = None,
        fc_col: str = "fold_over_control",
        condition_col: str = "condition",
        organ_col: str = "organ",
        peptide_col: str = "Peptide",
        condition: Optional[str] = None,
        control_peptide: Optional[str] = None,
        output_path: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create a figure with multiple peptide panels showing organ distribution.

        This is a convenience wrapper around plot_organ_distribution_boxplots
        that helps with filtering the data for specific conditions.

        Parameters:
        -----------
        df: pd.DataFrame
            DataFrame with fold change values
        peptides: List[str]
            List of peptides to plot
        organs: List[str]
            List of organs to include (if None, uses all in data)
        fc_col: str
            Column containing fold change values
        condition_col: str
            Column containing condition information
        organ_col: str
            Column containing organ information
        peptide_col: str
            Column containing peptide sequences
        condition: str
            Condition to filter for (if None, uses all)
        control_peptide: str
            Control peptide to highlight
        output_path: str
            Path to save figure (without extension)

        Returns:
        --------
        fig, axs: matplotlib figure and axes objects
        """
        # Make a copy of the dataframe to avoid modifying the original
        plot_df = df.copy()

        # Filter for the specified condition
        if condition and condition_col in plot_df.columns:
            if condition not in plot_df[condition_col].unique():
                raise ValueError(f"Condition '{condition}' not found in data")
            plot_df = plot_df[plot_df[condition_col] == condition]

        # Filter for the specified organs
        if organs and organ_col in plot_df.columns:
            plot_df = plot_df[plot_df[organ_col].isin(organs)]

        # Create organ abbreviations for better display
        if organ_col in plot_df.columns:
            # Create abbreviated organ names (first 2 characters)
            plot_df[f"{organ_col}_abbrev"] = plot_df[organ_col].apply(
                lambda x: x[:2].capitalize()
            )
            organ_display_col = f"{organ_col}_abbrev"
        else:
            organ_display_col = organ_col

        # Create the plot
        return self.plot_organ_distribution_boxplots(
            df=plot_df,
            peptides=peptides,
            fc_col=fc_col,
            organ_col=organ_display_col,
            peptide_col=peptide_col,
            control_peptide=control_peptide,
            output_path=output_path,
        )

    def get_palette(self, n_colors=None, palette_name=None):
        """Get a color palette with the requested number of colors.

        Parameters:
        -----------
        n_colors: int
            Number of colors to include in the palette
        palette_name: str
            Name of the seaborn color palette to use (default: use the one from config)

        Returns:
        --------
        list: Colors in the palette
        """
        # Use the palette from config or a default
        if palette_name is None:
            palette_name = self.config.get("palette", "viridis")

        # If no color count specified, use the default from the palette
        if n_colors is None:
            return sns.color_palette(palette_name)

        # Get the palette with the specified number of colors
        return sns.color_palette(palette_name, n_colors)
