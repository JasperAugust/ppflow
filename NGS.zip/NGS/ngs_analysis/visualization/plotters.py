"""Base plotting functionality.

This module provides the foundation for creating visualizations of phage display data.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
import os
import logging
from typing import Dict, List, Optional, Tuple, Union, Any


class BasePlotter:
    """Base class for all plotting functionality."""

    def __init__(self, config=None):
        self.config = config or {}

        # Default plot settings
        self.figure_size = self.config.get("figure_size", (12, 8))
        self.dpi = self.config.get("dpi", 150)
        self.style = self.config.get(
            "style", "seaborn-v0_8-whitegrid"
        )  # Updated for newer matplotlib
        self.font_scale = self.config.get("font_scale", 1.2)
        self.palette = self.config.get("palette", "deep")
        self.title_fontsize = self.config.get("title_fontsize", 16)
        self.axis_fontsize = self.config.get("axis_fontsize", 14)
        self.tick_fontsize = self.config.get("tick_fontsize", 12)
        self.legend_fontsize = self.config.get("legend_fontsize", 12)

        # Set default color palette
        sns.set_palette(self.palette)

        # Set font scale
        sns.set_context("notebook", font_scale=self.font_scale)

    def setup_figure(
        self, figsize: Optional[Tuple[float, float]] = None
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Set up a new figure for plotting.

        Parameters:
        -----------
        figsize: tuple
            Figure size in inches (width, height) or None to use defaults

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        plt.style.use(self.style)
        fig, ax = plt.subplots(figsize=figsize or self.figure_size, dpi=self.dpi)
        return fig, ax

    def save_figure(
        self,
        fig: plt.Figure,
        output_path: str,
        formats: Optional[List[str]] = None,
        create_dir: bool = True,
    ) -> List[str]:
        """Save figure to file in specified formats.

        Parameters:
        -----------
        fig: matplotlib figure
            Figure to save
        output_path: str
            Output path (without extension)
        formats: list
            List of formats to save as (default: ['png', 'pdf'])
        create_dir: bool
            Whether to create the output directory if it doesn't exist

        Returns:
        --------
        List of saved file paths
        """
        if formats is None:
            formats = ["png", "pdf"]

        # Create directory if it doesn't exist
        output_dir = os.path.dirname(output_path)
        if output_dir and create_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

        # Save in each format
        saved_files = []
        for fmt in formats:
            file_path = f"{output_path}.{fmt}"
            try:
                fig.savefig(file_path, bbox_inches="tight")
                saved_files.append(file_path)
            except Exception as e:
                logging.warning(f"Error saving figure to {file_path}: {str(e)}")

        return saved_files

    def format_axis(
        self,
        ax: plt.Axes,
        title: Optional[str] = None,
        xlabel: Optional[str] = None,
        ylabel: Optional[str] = None,
        xlim: Optional[Tuple[float, float]] = None,
        ylim: Optional[Tuple[float, float]] = None,
        xticks: Optional[List[float]] = None,
        yticks: Optional[List[float]] = None,
        xticklabels: Optional[List[str]] = None,
        yticklabels: Optional[List[str]] = None,
        legend: bool = True,
        legend_title: Optional[str] = None,
        grid: bool = True,
        spines: bool = True,
    ) -> plt.Axes:
        """Format axis with common settings.

        Parameters:
        -----------
        ax: matplotlib axes
            Axes to format
        title: str
            Title for the axes
        xlabel, ylabel: str
            Labels for x and y axes
        xlim, ylim: tuple
            Limits for x and y axes
        xticks, yticks: list
            Tick positions for x and y axes
        xticklabels, yticklabels: list
            Tick labels for x and y axes
        legend: bool
            Whether to show legend
        legend_title: str
            Title for the legend
        grid: bool
            Whether to show grid
        spines: bool
            Whether to show spines

        Returns:
        --------
        The formatted axes
        """
        # Set title and labels
        if title:
            ax.set_title(title, fontsize=self.title_fontsize)
        if xlabel:
            ax.set_xlabel(xlabel, fontsize=self.axis_fontsize)
        if ylabel:
            ax.set_ylabel(ylabel, fontsize=self.axis_fontsize)

        # Set limits
        if xlim:
            ax.set_xlim(xlim)
        if ylim:
            ax.set_ylim(ylim)

        # Set ticks
        if xticks is not None:
            ax.set_xticks(xticks)
        if yticks is not None:
            ax.set_yticks(yticks)

        # Set tick labels
        if xticklabels is not None:
            ax.set_xticklabels(
                xticklabels, rotation=45, ha="right", fontsize=self.tick_fontsize
            )
        else:
            for tick in ax.get_xticklabels():
                tick.set_fontsize(self.tick_fontsize)

        if yticklabels is not None:
            ax.set_yticklabels(yticklabels, fontsize=self.tick_fontsize)
        else:
            for tick in ax.get_yticklabels():
                tick.set_fontsize(self.tick_fontsize)

        # Set grid
        ax.grid(grid, axis="both", alpha=0.3)

        # Set spines
        for spine in ax.spines.values():
            spine.set_visible(spines)

        # Set legend
        if legend and ax.get_legend() is not None:
            ax.legend(title=legend_title, fontsize=self.legend_fontsize)
            if legend_title and ax.get_legend().get_title():
                ax.get_legend().get_title().set_fontsize(self.legend_fontsize)

        return ax

    def add_value_labels(
        self,
        ax: plt.Axes,
        fmt: str = "{:.2f}",
        offset: Tuple[float, float] = (0, 5),
        fontsize: Optional[int] = None,
        color: str = "black",
        horizontal: bool = False,
    ) -> plt.Axes:
        """Add value labels to a bar plot.

        Parameters:
        -----------
        ax: matplotlib axes
            Axes containing the bar plot
        fmt: str
            Format string for value labels
        offset: tuple
            Offset (x, y) for label positioning
        fontsize: int
            Font size for labels
        color: str
            Color for labels
        horizontal: bool
            Whether the bars are horizontal

        Returns:
        --------
        The formatted axes
        """
        if fontsize is None:
            fontsize = self.tick_fontsize - 2  # Slightly smaller than tick font

        for rect in ax.patches:
            if horizontal:
                width = rect.get_width()
                x = rect.get_x() + width + offset[0]
                y = rect.get_y() + rect.get_height() / 2 + offset[1]
                label = fmt.format(width)
                ax.text(
                    x, y, label, ha="left", va="center", fontsize=fontsize, color=color
                )
            else:
                height = rect.get_height()
                x = rect.get_x() + rect.get_width() / 2 + offset[0]
                y = rect.get_y() + height + offset[1]
                label = fmt.format(height)
                ax.text(
                    x,
                    y,
                    label,
                    ha="center",
                    va="bottom",
                    fontsize=fontsize,
                    color=color,
                )

        return ax

    def plot_barplot(
        self,
        data: pd.DataFrame,
        x: str,
        y: str,
        hue: Optional[str] = None,
        title: Optional[str] = None,
        xlabel: Optional[str] = None,
        ylabel: Optional[str] = None,
        figsize: Optional[Tuple[float, float]] = None,
        palette: Optional[str] = None,
        error_bars: bool = False,
        output_path: Optional[str] = None,
        value_labels: bool = False,
        sort_by: Optional[str] = None,
        ascending: bool = False,
        top_n: Optional[int] = None,
        horizontal: bool = False,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create a bar plot from DataFrame.

        Parameters:
        -----------
        data: pd.DataFrame
            Data to plot
        x: str
            Column to use for x-axis
        y: str
            Column to use for y-axis
        hue: str
            Column to use for color grouping
        title: str
            Plot title
        xlabel, ylabel: str
            Axis labels
        figsize: tuple
            Figure size (width, height) in inches
        palette: str
            Color palette name
        error_bars: bool
            Whether to include error bars (requires 'y_err' column)
        output_path: str
            Path to save figure (without extension)
        value_labels: bool
            Whether to add value labels to bars
        sort_by: str
            Column to sort by (default: None, use y if not specified)
        ascending: bool
            Sort order (default: False, highest first)
        top_n: int
            Limit to top N items
        horizontal: bool
            Whether to create a horizontal bar plot

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Make a copy to avoid modifying the original
        plot_data = data.copy()

        # Sort if requested
        if sort_by is not None:
            plot_data = plot_data.sort_values(sort_by, ascending=ascending)
        elif y is not None:
            plot_data = plot_data.sort_values(y, ascending=ascending)

        # Limit to top N if requested
        if top_n is not None and top_n > 0 and len(plot_data) > top_n:
            plot_data = plot_data.iloc[:top_n]

        # Create figure
        fig, ax = self.setup_figure(figsize)

        # Create plot
        if horizontal:
            sns.barplot(
                x=y,
                y=x,
                hue=hue,
                data=plot_data,
                palette=palette or self.palette,
                ax=ax,
            )
        else:
            sns.barplot(
                x=x,
                y=y,
                hue=hue,
                data=plot_data,
                palette=palette or self.palette,
                ax=ax,
            )

        # Format axis
        self.format_axis(ax, title=title, xlabel=xlabel or x, ylabel=ylabel or y)

        # Add value labels if requested
        if value_labels:
            self.add_value_labels(ax, horizontal=horizontal)

        # Save if output path provided
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_countplot(
        self,
        data: pd.DataFrame,
        x: str,
        hue: Optional[str] = None,
        title: Optional[str] = None,
        xlabel: Optional[str] = None,
        ylabel: Optional[str] = "Count",
        figsize: Optional[Tuple[float, float]] = None,
        palette: Optional[str] = None,
        output_path: Optional[str] = None,
        value_labels: bool = False,
        horizontal: bool = False,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create a count plot from DataFrame.

        Parameters:
        -----------
        data: pd.DataFrame
            Data to plot
        x: str
            Column to count
        hue: str
            Column to use for color grouping
        title: str
            Plot title
        xlabel, ylabel: str
            Axis labels
        figsize: tuple
            Figure size (width, height) in inches
        palette: str
            Color palette name
        output_path: str
            Path to save figure (without extension)
        value_labels: bool
            Whether to add value labels to bars
        horizontal: bool
            Whether to create a horizontal bar plot

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Create figure
        fig, ax = self.setup_figure(figsize)

        # Create plot
        if horizontal:
            sns.countplot(
                y=x, hue=hue, data=data, palette=palette or self.palette, ax=ax
            )
        else:
            sns.countplot(
                x=x, hue=hue, data=data, palette=palette or self.palette, ax=ax
            )

        # Format axis
        self.format_axis(ax, title=title, xlabel=xlabel or x, ylabel=ylabel)

        # Add value labels if requested
        if value_labels:
            self.add_value_labels(ax, fmt="{:.0f}", horizontal=horizontal)

        # Save if output path provided
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_heatmap(
        self,
        data: pd.DataFrame,
        x: Optional[str] = None,
        y: Optional[str] = None,
        value: Optional[str] = None,
        title: Optional[str] = None,
        xlabel: Optional[str] = None,
        ylabel: Optional[str] = None,
        figsize: Optional[Tuple[float, float]] = None,
        cmap: str = "viridis",
        center: Optional[float] = None,
        vmin: Optional[float] = None,
        vmax: Optional[float] = None,
        annot: bool = True,
        fmt: str = ".2f",
        output_path: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create a heatmap from DataFrame.

        Parameters:
        -----------
        data: pd.DataFrame
            Data to plot (if x, y, value are not provided, must be in matrix form)
        x: str
            Column to use for x-axis
        y: str
            Column to use for y-axis
        value: str
            Column to use for values
        title: str
            Plot title
        xlabel, ylabel: str
            Axis labels
        figsize: tuple
            Figure size (width, height) in inches
        cmap: str
            Colormap name
        center: float
            Center value for diverging colormaps
        vmin, vmax: float
            Value range for colormap
        annot: bool
            Whether to annotate cells with values
        fmt: str
            Format string for annotations
        output_path: str
            Path to save figure (without extension)

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Create pivot table if x, y, value provided
        if x is not None and y is not None and value is not None:
            pivot_data = pd.pivot_table(data, values=value, index=y, columns=x)
        else:
            pivot_data = data

        # Create figure
        fig, ax = self.setup_figure(figsize)

        # Create plot
        sns.heatmap(
            pivot_data,
            ax=ax,
            cmap=cmap,
            center=center,
            vmin=vmin,
            vmax=vmax,
            annot=annot,
            fmt=fmt,
        )

        # Format axis
        self.format_axis(ax, title=title, xlabel=xlabel or x, ylabel=ylabel or y)

        # Save if output path provided
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax

    def plot_scatterplot(
        self,
        data: pd.DataFrame,
        x: str,
        y: str,
        hue: Optional[str] = None,
        size: Optional[str] = None,
        title: Optional[str] = None,
        xlabel: Optional[str] = None,
        ylabel: Optional[str] = None,
        figsize: Optional[Tuple[float, float]] = None,
        palette: Optional[str] = None,
        size_norm: Optional[Tuple[float, float]] = (20, 500),
        alpha: float = 0.7,
        output_path: Optional[str] = None,
    ) -> Tuple[plt.Figure, plt.Axes]:
        """Create a scatter plot from DataFrame.

        Parameters:
        -----------
        data: pd.DataFrame
            Data to plot
        x: str
            Column to use for x-axis
        y: str
            Column to use for y-axis
        hue: str
            Column to use for color
        size: str
            Column to use for point size
        title: str
            Plot title
        xlabel, ylabel: str
            Axis labels
        figsize: tuple
            Figure size (width, height) in inches
        palette: str
            Color palette name
        size_norm: tuple
            Size normalization range (min, max)
        alpha: float
            Transparency
        output_path: str
            Path to save figure (without extension)

        Returns:
        --------
        fig, ax: matplotlib figure and axes objects
        """
        # Create figure
        fig, ax = self.setup_figure(figsize)

        # Create plot
        sns.scatterplot(
            x=x,
            y=y,
            hue=hue,
            size=size,
            sizes=size_norm if size else None,
            data=data,
            palette=palette or self.palette,
            alpha=alpha,
            ax=ax,
        )

        # Format axis
        self.format_axis(ax, title=title, xlabel=xlabel or x, ylabel=ylabel or y)

        # Save if output path provided
        if output_path:
            self.save_figure(fig, output_path)

        return fig, ax
